﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bidimensional3Archivo
{
    public partial class Form1 : Form
    {
        int[,] arregloBidi;
        int filas, columnas;
        TextWriter archivo;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCapturar_Click(object sender, EventArgs e)
        {
            filas = (int)nudFilas.Value;
            columnas = (int)nudColumnas.Value;

            arregloBidi = new int[filas, columnas];

            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    arregloBidi[i, j] = Convert.ToInt16(Interaction.InputBox("Introduce el elemento [" + i + "]  [" + j + "] : "));
                }
            }
            btnCapturar.Enabled = false;
            btnImprimir.Enabled = true;
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    rtbimprimir.Text += arregloBidi[i, j] + " ";
                    archivo.WriteLine(arregloBidi[i, j] + " ");
                }
                rtbimprimir.Text += "\n";
            }
            archivo.Close();
        }
    }
    
}
