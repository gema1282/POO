﻿using InputKey;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace numeroMayorMenorArchivo
{
    class claseMatriz
    {
        int[] numeros;
        int mayor, menor;

        public int Mayor { get => mayor; set => mayor = value; }
        public int Menor { get => menor; set => menor = value; }

        public void crearMatriz(int tamano)
        {
            numeros = new int[tamano];

            for (int i = 0; i < tamano; i++)
            {
                int valor = int.Parse(InputDialog.mostrar("Ingresa el valor"));
                numeros[i] = valor;
            }

            Mayor = numeros[0];
            Menor = numeros[0];

            for (int i = 0; i < tamano; i++)
            {
                if (numeros[i] > Mayor)
                {
                    Mayor = numeros[i];
                }
                else if (numeros[i] < Menor)
                {
                    Menor = numeros[i];
                }
            }
        }
        public string imprimirArreglo()
        {
            string texto = "";
            for (int i = 0; i < numeros.Length; i++)
            {
                texto = texto + "[ " + numeros[i] + " ] ";
            }
            return texto;
        }
    }
}
