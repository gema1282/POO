﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace numeroMayorMenorArchivo
{
    public partial class Form1 : Form
    {
        claseMatriz objMatriz = new claseMatriz();
        TextWriter archivo;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");

            objMatriz.crearMatriz(int.Parse(nUDTamano.Value.ToString()));

            lblMayor.Text = objMatriz.Mayor.ToString();
            lblMenor.Text = objMatriz.Menor.ToString();

            lblArreloUnidimensional.Text = objMatriz.imprimirArreglo();

            archivo.WriteLine(objMatriz.Mayor.ToString() + "\n" + objMatriz.Menor.ToString() + "\n");
            archivo.Close();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lblArreloUnidimensional.Text = "[ ]";
            lblMayor.Text = "0";
            lblMenor.Text = "0";
            nUDTamano.Value = 2;
        }
    }
}
