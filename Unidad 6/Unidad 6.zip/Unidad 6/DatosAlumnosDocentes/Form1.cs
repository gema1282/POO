﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatosAlumnosDocentes
{
    public partial class Form1 : Form
    {
        int contador = 1;

        Alumnos objAlumno = new Alumnos();
        Docentes objDocente = new Docentes();

        TextWriter archivo;
        string alumnosDocentes;

        public Form1()
        {
            objAlumno.Nombre = new string[100];
            objAlumno.FechaNacimiento = new DateTime[100];
            objAlumno.Curp = new string[100];
            objAlumno.Telefono = new string[100];
            objAlumno.Email = new string[100];
            objAlumno.Usuario = new string[100];
            objAlumno.NumeroControl = new string[100];
            objAlumno.Carrera = new string[100];
            objAlumno.Materia = new string[100];
            objAlumno.Calificacion = new string[100];

            objDocente.Nombre = new string[100];
            objDocente.FechaNacimiento = new DateTime[100];
            objDocente.Curp = new string[100];
            objDocente.Telefono = new string[100];
            objDocente.Email = new string[100];
            objDocente.Usuario = new string[100];
            objDocente.NumeroDocente = new string[100];
            objDocente.Sueldo = new string[100];
            objDocente.Materias = new string[100];

            InitializeComponent();

            cmbUsuario.Items.Add("Alumno");
            cmbUsuario.Items.Add("Docente");
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "")
            {
                errorProvider1.SetError(txtNombre, "Debe ingresar el nombre");
                txtNombre.Focus();
                return;
            }
            errorProvider1.SetError(txtNombre, "");

            if (txtCurp.Text == "")
            {
                errorProvider1.SetError(txtCurp, "Debe ingresar la curp");
                txtCurp.Focus();
                return;
            }
            errorProvider1.SetError(txtCurp, "");

            if (txtTelefono.Text == "")
            {
                errorProvider1.SetError(txtTelefono, "Debe ingresar un número de teléfono");
                txtTelefono.Focus();
                return;
            }
            errorProvider1.SetError(txtTelefono, "");

            if (txtEmail.Text == "")
            {
                errorProvider1.SetError(txtEmail, "Debe ingresar una dirección de email");
                txtEmail.Focus();
                return;
            }
            errorProvider1.SetError(txtEmail, "");

            if (cmbUsuario.Text == "Alumno")
            {
                this.txtNumeroControl.Enabled = true;
                this.txtCarrera.Enabled = true;
                this.txtMateria.Enabled = true;
                this.txtCalificacion.Enabled = true;

                this.txtNumDoc.Enabled = false;
                this.txtSueldo.Enabled = false;
                this.txtMateriasImp.Enabled = false;
            }
            else if (cmbUsuario.Text == "Docente")
            {
                this.txtNumDoc.Enabled = true;
                this.txtSueldo.Enabled = true;
                this.txtMateriasImp.Enabled = true;

                this.txtNumeroControl.Enabled = false;
                this.txtCarrera.Enabled = false;
                this.txtMateria.Enabled = false;
                this.txtCalificacion.Enabled = false;
            }

            this.btnGuardar.Enabled = true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (objAlumno.Materia.Length != 100)
            {
                if (cmbUsuario.Text == "Alumno")
                {
                    if (txtNumeroControl.Text == "")
                    {
                        errorProvider1.SetError(txtNumeroControl, "Debe ingresar un número de control");
                        txtNumeroControl.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumeroControl, "");

                    if (txtCarrera.Text == "")
                    {
                        errorProvider1.SetError(txtCarrera, "Debe ingresar una carrera");
                        txtCarrera.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCarrera, "");

                    if (txtMateria.Text == "")
                    {
                        errorProvider1.SetError(txtMateria, "Debe ingresar una materia");
                        txtMateria.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateria, "");

                    if (txtCalificacion.Text == "")
                    {
                        errorProvider1.SetError(txtCalificacion, "Debe ingresar una calificación");
                        txtCalificacion.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCalificacion, "");

                    objAlumno.Nombre[contador] = txtNombre.Text;
                    objAlumno.FechaNacimiento[contador] = dtpFechaNac.Value;
                    objAlumno.Curp[contador] = txtCurp.Text;
                    objAlumno.Telefono[contador] = txtTelefono.Text;
                    objAlumno.Email[contador] = txtEmail.Text;
                    objAlumno.Usuario[contador] = cmbUsuario.Text;
                    objAlumno.NumeroControl[contador] = txtNumeroControl.Text;
                    objAlumno.Carrera[contador] = txtCarrera.Text;
                    objAlumno.Materia[contador] = txtMateria.Text;
                    objAlumno.Calificacion[contador] = txtCalificacion.Text;

                    alumnosDocentes += objAlumno.Nombre[contador] + "\n";
                    alumnosDocentes += objAlumno.FechaNacimiento[contador] + "\n";
                    alumnosDocentes += objAlumno.Curp[contador] + "\n";
                    alumnosDocentes += objAlumno.Telefono[contador] + "\n";
                    alumnosDocentes += objAlumno.Email[contador] + "\n";
                    alumnosDocentes += objAlumno.Usuario[contador] + "\n";
                    alumnosDocentes += objAlumno.NumeroControl[contador] + "\n";
                    alumnosDocentes += objAlumno.Carrera[contador] + "\n";
                    alumnosDocentes += objAlumno.Materia[contador] + "\n";
                    alumnosDocentes += objAlumno.Calificacion[contador] + "\n";
                }
                else if (cmbUsuario.Text == "Docente")
                {
                    if (txtNumDoc.Text == "")
                    {
                        errorProvider1.SetError(txtNumDoc, "Debe ingresar un número de docente");
                        txtNumDoc.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumDoc, "");

                    if (txtSueldo.Text == "")
                    {
                        errorProvider1.SetError(txtSueldo, "Debe ingresar un sueldo");
                        txtSueldo.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtSueldo, "");

                    if (txtMateriasImp.Text == "")
                    {
                        errorProvider1.SetError(txtMateriasImp, "Debe ingresar una materia");
                        txtMateriasImp.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateriasImp, "");

                    objDocente.Nombre[contador] = txtNombre.Text;
                    objDocente.FechaNacimiento[contador] = dtpFechaNac.Value;
                    objDocente.Curp[contador] = txtCurp.Text;
                    objDocente.Telefono[contador] = txtTelefono.Text;
                    objDocente.Email[contador] = txtEmail.Text;
                    objDocente.Usuario[contador] = cmbUsuario.Text;
                    objDocente.NumeroDocente[contador] = txtNumDoc.Text;
                    objDocente.Sueldo[contador] = txtSueldo.Text;
                    objDocente.Materias[contador] = txtMateriasImp.Text;

                    alumnosDocentes += objDocente.Nombre[contador] + "\n";
                    alumnosDocentes += objDocente.FechaNacimiento[contador] + "\n";
                    alumnosDocentes += objDocente.Curp[contador] + "\n";
                    alumnosDocentes += objDocente.Telefono[contador] + "\n";
                    alumnosDocentes += objDocente.Email[contador] + "\n";
                    alumnosDocentes += objDocente.Usuario[contador] + "\n";
                    alumnosDocentes += objDocente.NumeroDocente[contador] + "\n";
                    alumnosDocentes += objDocente.Sueldo[contador] + "\n";
                    alumnosDocentes += objDocente.Materias[contador] + "\n";
                }

                contador++;
            }
            else
            {
                if (cmbUsuario.Text == "Alumno")
                {
                    if (txtNumeroControl.Text == "")
                    {
                        errorProvider1.SetError(txtNumeroControl, "Debe ingresar un número de comtrol");
                        txtNumeroControl.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumeroControl, "");

                    if (txtCarrera.Text == "")
                    {
                        errorProvider1.SetError(txtCarrera, "Debe ingresar una carrera");
                        txtCarrera.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCarrera, "");

                    if (txtMateria.Text == "")
                    {
                        errorProvider1.SetError(txtMateria, "Debe ingresar una materia");
                        txtMateria.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateria, "");

                    if (txtCalificacion.Text == "")
                    {
                        errorProvider1.SetError(txtCalificacion, "Debe ingresar una calificación");
                        txtCalificacion.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCalificacion, "");

                    objAlumno.Nombre = new string[10];
                    objAlumno.Nombre[0] = txtNombre.Text;

                    objAlumno.FechaNacimiento = new DateTime[10];
                    objAlumno.FechaNacimiento[0] = dtpFechaNac.Value;

                    objAlumno.Curp = new string[10];
                    objAlumno.Curp[0] = txtCurp.Text;

                    objAlumno.Telefono = new string[10];
                    objAlumno.Telefono[0] = txtTelefono.Text;

                    objAlumno.Email = new string[10];
                    objAlumno.Email[0] = txtEmail.Text;

                    objAlumno.Usuario = new string[10];
                    objAlumno.Usuario[0] = cmbUsuario.Text;

                    objAlumno.NumeroControl = new string[10];
                    objAlumno.NumeroControl[0] = txtNumeroControl.Text;

                    objAlumno.Carrera = new string[10];
                    objAlumno.Carrera[0] = txtCarrera.Text;

                    objAlumno.Materia = new string[10];
                    objAlumno.Materia[0] = txtMateria.Text;

                    objAlumno.Calificacion = new string[10];
                    objAlumno.Calificacion[0] = txtCalificacion.Text;

                    alumnosDocentes += objAlumno.Nombre[0] + "\n";
                    alumnosDocentes += objAlumno.FechaNacimiento[0] + "\n";
                    alumnosDocentes += objAlumno.Curp[0] + "\n";
                    alumnosDocentes += objAlumno.Telefono[0] + "\n";
                    alumnosDocentes += objAlumno.Email[0] + "\n";
                    alumnosDocentes += objAlumno.Usuario[0] + "\n";
                    alumnosDocentes += objAlumno.NumeroControl[0] + "\n";
                    alumnosDocentes += objAlumno.Carrera[0] + "\n";
                    alumnosDocentes += objAlumno.Materia[0] + "\n";
                    alumnosDocentes += objAlumno.Calificacion[0] + "\n";
                }
                else if (cmbUsuario.Text == "Docente")
                {
                    if (txtNumDoc.Text == "")
                    {
                        errorProvider1.SetError(txtNumDoc, "Debe ingresar un número de docente");
                        txtNumDoc.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumDoc, "");

                    if (txtSueldo.Text == "")
                    {
                        errorProvider1.SetError(txtSueldo, "Debe ingresar un sueldo");
                        txtSueldo.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtSueldo, "");

                    if (txtMateriasImp.Text == "")
                    {
                        errorProvider1.SetError(txtMateriasImp, "Debe ingresar una materia");
                        txtMateriasImp.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateriasImp, "");

                    objDocente.Nombre = new string[10];
                    objDocente.Nombre[0] = txtNombre.Text;

                    objDocente.FechaNacimiento = new DateTime[10];
                    objAlumno.FechaNacimiento[0] = dtpFechaNac.Value;

                    objDocente.Curp = new string[10];
                    objDocente.Curp[0] = txtCurp.Text;

                    objDocente.Telefono = new string[10];
                    objAlumno.Telefono[0] = txtTelefono.Text;

                    objDocente.Email = new string[10];
                    objDocente.Email[0] = txtEmail.Text;

                    objDocente.Usuario = new string[10];
                    objDocente.Usuario[0] = cmbUsuario.Text;

                    objDocente.NumeroDocente = new string[10];
                    objDocente.NumeroDocente[0] = txtNumDoc.Text;

                    objDocente.Sueldo = new string[10];
                    objDocente.Sueldo[0] = txtSueldo.Text;

                    objDocente.Materias = new string[10];
                    objDocente.Materias[0] = txtMateriasImp.Text;

                    alumnosDocentes += objDocente.Nombre[0] + "\n";
                    alumnosDocentes += objDocente.FechaNacimiento[0] + "\n";
                    alumnosDocentes += objDocente.Curp[0] + "\n";
                    alumnosDocentes += objDocente.Telefono[0] + "\n";
                    alumnosDocentes += objDocente.Email[0] + "\n";
                    alumnosDocentes += objDocente.Usuario[0] + "\n";
                    alumnosDocentes += objDocente.NumeroDocente[0] + "\n";
                    alumnosDocentes += objDocente.Sueldo[0] + "\n";
                    alumnosDocentes += objDocente.Materias[0] + "\n";
                }

                this.btnImprimir.Enabled = true;

                archivo.Write(alumnosDocentes);
                archivo.Close();
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (cmbUsuario.Text == "Alumno")
            {
                MessageBox.Show("Nombre: " + txtNombre.Text + "\n" + "Fecha de nacimiento: " + dtpFechaNac.Text + "\n" + "Curp: " + txtCurp.Text + "\n" + "Teléfono: " + txtTelefono.Text + "\n" + "Email: " + txtEmail.Text + "\n" + "Usuario: " + cmbUsuario.Text + "\n" + "Número de control: " + txtNumeroControl.Text + "\n" + "Carrera: " + txtCarrera.Text + "\n" + "Materia: " + txtMateria.Text + "\n" + "Calficación: " + txtCalificacion.Text);

                txtNombre.Text = "";
                txtCurp.Text = "";
                txtTelefono.Text = "";
                txtEmail.Text = "";
                txtNumeroControl.Text = "";
                txtCarrera.Text = "";
                txtMateria.Text = "";
                txtCalificacion.Text = "";
            }
            else if (cmbUsuario.Text == "Docente")
            {
                MessageBox.Show("Nombre: " + txtNombre.Text + "\n" + "Fecha de nacimiento: " + dtpFechaNac.Text + "\n" + "Curp: " + txtCurp.Text + "\n" + "Teléfono: " + txtTelefono.Text + "\n" + "Email: " + txtEmail.Text + "\n" + "Usuario: " + cmbUsuario.Text + "\n" + "Número de docente: " + txtNumDoc + "\n" + "Sueldo: " + txtSueldo.Text + "\n" + "Materia que imparte: " + txtMateriasImp.Text);

                txtNombre.Text = "";
                txtCurp.Text = "";
                txtTelefono.Text = "";
                txtEmail.Text = "";
                txtNumDoc.Text = "";
                txtSueldo.Text = "";
                txtMateriasImp.Text = "";
            }
        }
    }
}
