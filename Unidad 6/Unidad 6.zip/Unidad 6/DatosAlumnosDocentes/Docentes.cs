﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosAlumnosDocentes
{
    class Docentes : Personas
    {
        public string[] NumeroDocente { set; get; }
        public string[] Sueldo { set; get; }
        public string[] Materias;
    }
}
