﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlumnoDocenteArchivo
{
    class Persona
    {
        public string Nombre { set; get; }
        public DateTime FechaNacimiento { set; get; }
        public string Curp { set; get; }
        public string Telefono { set; get; }
        public string Email { set; get; }
        public string Usuario { set; get; }
    }
}
