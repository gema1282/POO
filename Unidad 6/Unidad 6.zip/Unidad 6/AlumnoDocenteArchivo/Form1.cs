﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlumnoDocenteArchivo
{
    public partial class Form1 : Form
    {
        int contador = 1;

        Alumno objAlumno = new Alumno();
        Docente objDocente = new Docente();
        TextWriter archivo;

        public Form1()
        {
            objAlumno.Materia = new string[100];
            objAlumno.Calificacion = new string[100];
            objDocente.Materias = new string[100];

            InitializeComponent();

            cmbUsuario.Items.Add("Alumno");
            cmbUsuario.Items.Add("Docente");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text == "")
            {
                errorProvider1.SetError(txtNombre, "Debe ingresar el nombre");
                txtNombre.Focus();
                return;
            }
            errorProvider1.SetError(txtNombre, "");

            if (txtCurp.Text == "")
            {
                errorProvider1.SetError(txtCurp, "Debe ingresar la curp");
                txtCurp.Focus();
                return;
            }
            errorProvider1.SetError(txtCurp, "");

            if (txtTelefono.Text == "")
            {
                errorProvider1.SetError(txtTelefono, "Debe ingresar un número de teléfono");
                txtTelefono.Focus();
                return;
            }
            errorProvider1.SetError(txtTelefono, "");

            if (txtEmail.Text == "")
            {
                errorProvider1.SetError(txtEmail, "Debe ingresar una dirección de email");
                txtEmail.Focus();
                return;
            }
            errorProvider1.SetError(txtEmail, "");


            if (cmbUsuario.Text == "Alumno")
            {
                this.txtNumeroControl.Enabled = true;
                this.txtCarrera.Enabled = true;
                this.txtMateria.Enabled = true;
                this.txtCalificacion.Enabled = true;

                this.txtNumDoc.Enabled = false;
                this.txtSueldo.Enabled = false;
                this.txtMateriasImp.Enabled = false;

                objAlumno.Nombre = txtNombre.Text;
                objAlumno.FechaNacimiento = dtpFechaNac.Value;
                objAlumno.Curp = txtCurp.Text;
                objAlumno.Telefono = txtTelefono.Text;
                objAlumno.Email = txtEmail.Text;
                objAlumno.Usuario = cmbUsuario.Text;

            }
            else if (cmbUsuario.Text == "Docente")
            {
                this.txtNumDoc.Enabled = true;
                this.txtSueldo.Enabled = true;
                this.txtMateriasImp.Enabled = true;

                this.txtNumeroControl.Enabled = false;
                this.txtCarrera.Enabled = false;
                this.txtMateria.Enabled = false;
                this.txtCalificacion.Enabled = false;

                objDocente.Nombre = txtNombre.Text;
                objDocente.FechaNacimiento = dtpFechaNac.Value;
                objDocente.Curp = txtCurp.Text;
                objDocente.Telefono = txtTelefono.Text;
                objDocente.Email = txtEmail.Text;
                objDocente.Usuario = cmbUsuario.Text;
            }

            this.btnGuardar.Enabled = true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");

            if (objAlumno.Materia.Length != 100)
            {
                if (cmbUsuario.Text == "Alumno")
                {
                    if (txtNumeroControl.Text == "")
                    {
                        errorProvider1.SetError(txtNumeroControl, "Debe ingresar un número de control");
                        txtNumeroControl.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumeroControl, "");

                    if (txtCarrera.Text == "")
                    {
                        errorProvider1.SetError(txtCarrera, "Debe ingresar una carrera");
                        txtCarrera.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCarrera, "");

                    if (txtMateria.Text == "")
                    {
                        errorProvider1.SetError(txtMateria, "Debe ingresar una materia");
                        txtMateria.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateria, "");

                    if (txtCalificacion.Text == "")
                    {
                        errorProvider1.SetError(txtCalificacion, "Debe ingresar una calificación");
                        txtCalificacion.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCalificacion, "");


                    objAlumno.NumeroControl = txtNumeroControl.Text;
                    objAlumno.Carrera = txtCarrera.Text;

                    objAlumno.Materia[contador] = txtMateria.Text;
                    objAlumno.Calificacion[contador] = txtCalificacion.Text;

                    archivo.WriteLine(objAlumno.Materia[contador] + "\n" + objAlumno.Calificacion[contador] + "\n");
                }
                else if (cmbUsuario.Text == "Docente")
                {
                    if (txtNumDoc.Text == "")
                    {
                        errorProvider1.SetError(txtNumDoc, "Debe ingresar un número de docente");
                        txtNumDoc.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumDoc, "");

                    if (txtSueldo.Text == "")
                    {
                        errorProvider1.SetError(txtSueldo, "Debe ingresar un sueldo");
                        txtSueldo.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtSueldo, "");

                    if (txtMateriasImp.Text == "")
                    {
                        errorProvider1.SetError(txtMateriasImp, "Debe ingresar una materia");
                        txtMateriasImp.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateriasImp, "");


                    objDocente.NumeroDocente = txtNumDoc.Text;
                    objDocente.Sueldo = txtSueldo.Text;

                    objDocente.Materias[contador] = txtMateriasImp.Text;

                    archivo.WriteLine(objDocente.Materias[contador]);
                }

                contador++;
            }
            else
            {
                if (cmbUsuario.Text == "Alumno")
                {
                    if (txtNumeroControl.Text == "")
                    {
                        errorProvider1.SetError(txtNumeroControl, "Debe ingresar un número de comtrol");
                        txtNumeroControl.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumeroControl, "");

                    if (txtCarrera.Text == "")
                    {
                        errorProvider1.SetError(txtCarrera, "Debe ingresar una carrera");
                        txtCarrera.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCarrera, "");

                    if (txtMateria.Text == "")
                    {
                        errorProvider1.SetError(txtMateria, "Debe ingresar una materia");
                        txtMateria.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateria, "");

                    if (txtCalificacion.Text == "")
                    {
                        errorProvider1.SetError(txtCalificacion, "Debe ingresar una calificación");
                        txtCalificacion.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtCalificacion, "");


                    objAlumno.NumeroControl = txtNumeroControl.Text;
                    objAlumno.Carrera = txtCarrera.Text;

                    objAlumno.Materia = new string[10];
                    objAlumno.Materia[0] = txtMateria.Text;

                    objAlumno.Calificacion = new string[10];
                    objAlumno.Calificacion[0] = txtCalificacion.Text;

                    archivo.WriteLine(objAlumno.Materia[0] + "\n" + objAlumno.Calificacion[0] + "\n");
                }
                else if (cmbUsuario.Text == "Docente")
                {
                    if (txtNumDoc.Text == "")
                    {
                        errorProvider1.SetError(txtNumDoc, "Debe ingresar un número de docente");
                        txtNumDoc.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtNumDoc, "");

                    if (txtSueldo.Text == "")
                    {
                        errorProvider1.SetError(txtSueldo, "Debe ingresar un sueldo");
                        txtSueldo.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtSueldo, "");

                    if (txtMateriasImp.Text == "")
                    {
                        errorProvider1.SetError(txtMateriasImp, "Debe ingresar una materia");
                        txtMateriasImp.Focus();
                        return;
                    }
                    errorProvider1.SetError(txtMateriasImp, "");

                    objDocente.NumeroDocente = txtNumDoc.Text;
                    objDocente.Sueldo = txtSueldo.Text;

                    objDocente.Materias = new string[10];
                    objDocente.Materias[0] = txtMateriasImp.Text;

                    archivo.WriteLine(objDocente.Materias[0]);
                }

                archivo.Close();
                this.btnImprimir.Enabled = true;
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            if (cmbUsuario.Text == "Alumno")
            {
                MessageBox.Show("Materia: " + txtMateria.Text + "\n" + "Calficación: " + txtCalificacion.Text);

                txtMateria.Text = "";
                txtCalificacion.Text = "";
            }
            else if (cmbUsuario.Text == "Docente")
            {
                MessageBox.Show("Materia que imparte: " + txtMateriasImp.Text);

                txtMateriasImp.Text = "";
            }
        }
    }
}
