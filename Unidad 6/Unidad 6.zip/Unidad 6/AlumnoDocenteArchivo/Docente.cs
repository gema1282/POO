﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlumnoDocenteArchivo
{
    class Docente : Persona
    {
        public string NumeroDocente { set; get; }
        public string Sueldo { set; get; }
        public string[] Materias;
    }
}
