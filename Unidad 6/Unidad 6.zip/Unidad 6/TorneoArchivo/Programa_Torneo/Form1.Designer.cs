﻿namespace Programa_Torneo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblnumPartido = new System.Windows.Forms.Label();
            this.lblNombre2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnSigNombre = new System.Windows.Forms.Button();
            this.btnEstablecerPuntajes = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numPerder = new System.Windows.Forms.NumericUpDown();
            this.numEmpatar = new System.Windows.Forms.NumericUpDown();
            this.numGanar = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txbNombre = new System.Windows.Forms.TextBox();
            this.lblNombreEquipo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnContinuar1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.numEquipos = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label13 = new System.Windows.Forms.Label();
            this.lblEquipoGanador = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPerder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEmpatar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGanar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquipos)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btnNext);
            this.panel1.Controls.Add(this.lblnumPartido);
            this.panel1.Controls.Add(this.lblNombre2);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.btnSigNombre);
            this.panel1.Controls.Add(this.btnEstablecerPuntajes);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.numPerder);
            this.panel1.Controls.Add(this.numEmpatar);
            this.panel1.Controls.Add(this.numGanar);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txbNombre);
            this.panel1.Controls.Add(this.lblNombreEquipo);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnContinuar1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.numEquipos);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(289, 447);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnNext
            // 
            this.btnNext.Enabled = false;
            this.btnNext.Location = new System.Drawing.Point(103, 417);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(65, 23);
            this.btnNext.TabIndex = 22;
            this.btnNext.Text = "Siguiente";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblnumPartido
            // 
            this.lblnumPartido.AutoSize = true;
            this.lblnumPartido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumPartido.Location = new System.Drawing.Point(211, 322);
            this.lblnumPartido.Name = "lblnumPartido";
            this.lblnumPartido.Size = new System.Drawing.Size(0, 15);
            this.lblnumPartido.TabIndex = 21;
            // 
            // lblNombre2
            // 
            this.lblNombre2.AutoSize = true;
            this.lblNombre2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre2.Location = new System.Drawing.Point(97, 352);
            this.lblNombre2.Name = "lblNombre2";
            this.lblNombre2.Size = new System.Drawing.Size(0, 24);
            this.lblNombre2.TabIndex = 20;
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Ganó",
            "Perdió",
            "Empató"});
            this.comboBox1.Location = new System.Drawing.Point(83, 390);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(46, 357);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Equipo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(81, 322);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 15);
            this.label9.TabIndex = 17;
            this.label9.Text = "Resultados partido:";
            // 
            // btnSigNombre
            // 
            this.btnSigNombre.Enabled = false;
            this.btnSigNombre.Location = new System.Drawing.Point(190, 165);
            this.btnSigNombre.Name = "btnSigNombre";
            this.btnSigNombre.Size = new System.Drawing.Size(65, 23);
            this.btnSigNombre.TabIndex = 4;
            this.btnSigNombre.Text = "Siguiente";
            this.btnSigNombre.UseVisualStyleBackColor = true;
            this.btnSigNombre.Click += new System.EventHandler(this.btnSigNombre_Click);
            // 
            // btnEstablecerPuntajes
            // 
            this.btnEstablecerPuntajes.Enabled = false;
            this.btnEstablecerPuntajes.Location = new System.Drawing.Point(85, 278);
            this.btnEstablecerPuntajes.Name = "btnEstablecerPuntajes";
            this.btnEstablecerPuntajes.Size = new System.Drawing.Size(120, 23);
            this.btnEstablecerPuntajes.TabIndex = 8;
            this.btnEstablecerPuntajes.Text = "Establecer Puntajes";
            this.btnEstablecerPuntajes.UseVisualStyleBackColor = true;
            this.btnEstablecerPuntajes.Click += new System.EventHandler(this.btnEstablecerPuntajes_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(193, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Perder:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(100, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Empatar:";
            // 
            // numPerder
            // 
            this.numPerder.Enabled = false;
            this.numPerder.Location = new System.Drawing.Point(236, 247);
            this.numPerder.Name = "numPerder";
            this.numPerder.Size = new System.Drawing.Size(35, 20);
            this.numPerder.TabIndex = 7;
            // 
            // numEmpatar
            // 
            this.numEmpatar.Enabled = false;
            this.numEmpatar.Location = new System.Drawing.Point(148, 247);
            this.numEmpatar.Name = "numEmpatar";
            this.numEmpatar.Size = new System.Drawing.Size(35, 20);
            this.numEmpatar.TabIndex = 6;
            this.numEmpatar.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numGanar
            // 
            this.numGanar.Enabled = false;
            this.numGanar.Location = new System.Drawing.Point(58, 247);
            this.numGanar.Name = "numGanar";
            this.numGanar.Size = new System.Drawing.Size(35, 20);
            this.numGanar.TabIndex = 5;
            this.numGanar.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Ganar:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 218);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Seleccione una puntuación";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(180, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Datos de los partidos";
            // 
            // txbNombre
            // 
            this.txbNombre.Enabled = false;
            this.txbNombre.Location = new System.Drawing.Point(140, 142);
            this.txbNombre.Name = "txbNombre";
            this.txbNombre.Size = new System.Drawing.Size(115, 20);
            this.txbNombre.TabIndex = 3;
            // 
            // lblNombreEquipo
            // 
            this.lblNombreEquipo.AutoSize = true;
            this.lblNombreEquipo.Location = new System.Drawing.Point(25, 145);
            this.lblNombreEquipo.Name = "lblNombreEquipo";
            this.lblNombreEquipo.Size = new System.Drawing.Size(99, 13);
            this.lblNombreEquipo.TabIndex = 5;
            this.lblNombreEquipo.Text = "Nombre del equipo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(75, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Datos de equipos";
            // 
            // btnContinuar1
            // 
            this.btnContinuar1.Location = new System.Drawing.Point(192, 84);
            this.btnContinuar1.Name = "btnContinuar1";
            this.btnContinuar1.Size = new System.Drawing.Size(65, 23);
            this.btnContinuar1.TabIndex = 2;
            this.btnContinuar1.Text = "Continuar";
            this.btnContinuar1.UseVisualStyleBackColor = true;
            this.btnContinuar1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Datos del Torneo";
            // 
            // numEquipos
            // 
            this.numEquipos.Location = new System.Drawing.Point(214, 58);
            this.numEquipos.Name = "numEquipos";
            this.numEquipos.Size = new System.Drawing.Size(43, 20);
            this.numEquipos.TabIndex = 1;
            this.numEquipos.ThousandsSeparator = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero de equipos participantes:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Location = new System.Drawing.Point(307, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(526, 282);
            this.panel2.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(4, 165);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(236, 20);
            this.label12.TabIndex = 25;
            this.label12.Text = "Tabla de Puntuaciones Final";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(8, 188);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(509, 79);
            this.dataGridView2.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(149, 20);
            this.label11.TabIndex = 23;
            this.label11.Text = "Tabla de Partidos";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 41);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(509, 121);
            this.dataGridView1.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Goldenrod;
            this.label13.Location = new System.Drawing.Point(432, 319);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(269, 37);
            this.label13.TabIndex = 1;
            this.label13.Text = "Equipo ganador:";
            // 
            // lblEquipoGanador
            // 
            this.lblEquipoGanador.AutoSize = true;
            this.lblEquipoGanador.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEquipoGanador.ForeColor = System.Drawing.Color.Goldenrod;
            this.lblEquipoGanador.Location = new System.Drawing.Point(409, 370);
            this.lblEquipoGanador.Name = "lblEquipoGanador";
            this.lblEquipoGanador.Size = new System.Drawing.Size(0, 37);
            this.lblEquipoGanador.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(845, 471);
            this.Controls.Add(this.lblEquipoGanador);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPerder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEmpatar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGanar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numEquipos)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown numEquipos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnContinuar1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnEstablecerPuntajes;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numPerder;
        private System.Windows.Forms.NumericUpDown numEmpatar;
        private System.Windows.Forms.NumericUpDown numGanar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbNombre;
        private System.Windows.Forms.Label lblNombreEquipo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSigNombre;
        private System.Windows.Forms.Label lblnumPartido;
        private System.Windows.Forms.Label lblNombre2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblEquipoGanador;
    }
}

