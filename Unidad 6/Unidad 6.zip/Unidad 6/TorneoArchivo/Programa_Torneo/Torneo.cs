﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa_Torneo
{

    class Torneo
    {
        public int numero_equipos { set; get; }
        public string[,] puntaje_partido { set; get; }
        public int[] total_puntos { get; set; }
        public string equipoLocal { get; set; }
        public string equipoVisitante { get; set; }
        public int Puntos_ganar { get; set; }
        public int Puntos_empatar { get; set; }
        public int Puntos_perder { get; set; }

    }
}
