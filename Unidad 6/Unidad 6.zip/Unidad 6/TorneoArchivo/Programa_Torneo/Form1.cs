﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Programa_Torneo
{
    public partial class Form1 : Form
    {
        Torneo objTorneo = new Torneo();
        int cont = 0;
        string[] totalarr;
        int[] totalInt;
        int campeon;
        int equipo = 0;
        int partido = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (numEquipos.Value > 1)
            {
                objTorneo.numero_equipos = Convert.ToInt32(numEquipos.Value);
                txbNombre.Enabled = true;
                btnSigNombre.Enabled = true;
                btnContinuar1.Enabled = false;
                numEquipos.Enabled = false;
                lblNombreEquipo.Text = "Nombre del Equipo " + (cont + 1) + ":";
                objTorneo.puntaje_partido = new string[objTorneo.numero_equipos, objTorneo.numero_equipos];
            }
            else
            {
                MessageBox.Show("Seleccione un numero MAYOR a 1 antes de continuar");
            }

        }

        private void btnSigNombre_Click(object sender, EventArgs e)
        {
            if (!txbNombre.Text.Equals(""))
            {
                if ((cont + 1) >= objTorneo.puntaje_partido.GetLength(0))
                {
                    objTorneo.puntaje_partido[cont, 0] = txbNombre.Text;
                    MessageBox.Show("Nombres registrados correctamente");
                    txbNombre.Enabled = false;
                    btnSigNombre.Enabled = false;
                    btnEstablecerPuntajes.Enabled = true;
                    numEmpatar.Enabled = true;
                    numGanar.Enabled = true;
                    numPerder.Enabled = true;
                }
                else
                {
                    objTorneo.puntaje_partido[cont, 0] = txbNombre.Text;
                    txbNombre.Clear();
                    cont++;
                    lblNombreEquipo.Text = "Nombre del Equipo " + (cont + 1) + ":";
                }
            }
            else {
                MessageBox.Show("Ingresa algo nmms");
            }
            

        }

        private void btnEstablecerPuntajes_Click(object sender, EventArgs e)
        {
            if (numGanar.Value > 0 && numEmpatar.Value > 0)
            {
                objTorneo.Puntos_empatar = Convert.ToInt32(numEmpatar.Value);
                objTorneo.Puntos_ganar = Convert.ToInt32(numGanar.Value);
                objTorneo.Puntos_perder = Convert.ToInt32(numPerder.Value);
                btnEstablecerPuntajes.Enabled = false;
                numEmpatar.Enabled = false;
                numGanar.Enabled = false;
                numPerder.Enabled = false;
                comboBox1.Enabled = true;
                btnNext.Enabled = true;
                lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                lblnumPartido.Text = partido.ToString();
            }
            else
            {
                MessageBox.Show("Se recomienda establecer un numero mayor a 0 en Ganar y Empatar");
            }


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {


            if (objTorneo.puntaje_partido.GetLength(0) == 2)
            {
                if (equipo + 1 == 2)
                {
                    switch (comboBox1.SelectedItem)
                    {
                        case "Ganó":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_ganar.ToString();
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                if (x == 0)
                                {
                                    dataGridView1.Columns.Add("nombre", "Nombre");
                                    for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                    {
                                        dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                    }
                                }
                                for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    row[y] = objTorneo.puntaje_partido[x, y];
                                }
                                dataGridView1.Rows.Add(row);
                            }
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                int total = 0;
                                if (x==0)
                                {
                                    totalarr = new string[objTorneo.numero_equipos];
                                    totalInt = new int[objTorneo.numero_equipos];
                                    for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                    {
                                        dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                    }
                                }
                               
                                for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                }
                                totalarr[x] = total.ToString();
                            }
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                totalInt[i] = Convert.ToInt32(totalarr[i]);
                            }
                            campeon = totalInt.Max();
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                if (totalInt[i]==campeon)
                                {
                                    comboBox1.Enabled = false;
                                    btnNext.Enabled = false;
                                    lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0]+ " con "+ campeon+ " Puntos";
                                    using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                    {

                                        Outputfile.WriteLine(lblEquipoGanador.Text);

                                    }
                                }
                            }
                            dataGridView2.Rows.Add(totalarr);
                            break;
                        case "Perdió":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_perder.ToString();
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                if (x == 0)
                                {
                                    dataGridView1.Columns.Add("nombre", "Nombre");
                                    for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                    {
                                        dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                    }
                                }
                                for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    row[y] = objTorneo.puntaje_partido[x, y];
                                }
                                dataGridView1.Rows.Add(row);
                            }
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                int total = 0;
                                if (x == 0)
                                {
                                    totalarr = new string[objTorneo.numero_equipos];
                                    totalInt = new int[objTorneo.numero_equipos];
                                    for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                    {
                                        dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                    }
                                }

                                for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                }
                                totalarr[x] = total.ToString();
                            }
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                totalInt[i] = Convert.ToInt32(totalarr[i]);
                            }
                            campeon = totalInt.Max();
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                if (totalInt[i] == campeon)
                                {
                                    comboBox1.Enabled = false;
                                    btnNext.Enabled = false;
                                    lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0] + " con " + campeon + " Puntos";
                                    using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                    {

                                        Outputfile.WriteLine(lblEquipoGanador.Text);

                                    }
                                }
                            }
                            dataGridView2.Rows.Add(totalarr);
                            break;
                        case "Empató":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_empatar.ToString();
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                if (x == 0)
                                {
                                    dataGridView1.Columns.Add("nombre", "Nombre");
                                    for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                    {
                                        dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                    }
                                }
                                for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    row[y] = objTorneo.puntaje_partido[x, y];
                                }
                                dataGridView1.Rows.Add(row);
                            }
                            for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                            {
                                int total = 0;
                                if (x == 0)
                                {
                                    totalarr = new string[objTorneo.numero_equipos];
                                    totalInt = new int[objTorneo.numero_equipos];
                                    for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                    {
                                        dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                    }
                                }

                                for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                {
                                    total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                }
                                totalarr[x] = total.ToString();
                            }
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                totalInt[i] = Convert.ToInt32(totalarr[i]);
                            }
                            campeon = totalInt.Max();
                            for (int i = 0; i < totalarr.Length; i++)
                            {
                                if (totalInt[i] == campeon)
                                {
                                    comboBox1.Enabled = false;
                                    btnNext.Enabled = false;
                                    lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0] + " con " + campeon + " Puntos";
                                    using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                    {

                                        Outputfile.WriteLine(lblEquipoGanador.Text);

                                    }
                                }
                            }
                            dataGridView2.Rows.Add(totalarr);
                            break;
                        default:
                            break;
                    }
                }
                else
                    switch (comboBox1.SelectedItem)
                    {
                        case "Ganó":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_ganar.ToString();
                            equipo++;
                            lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                            break;
                        case "Perdió":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_perder.ToString();
                            equipo++;
                            lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                            break;
                        case "Empató":
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_empatar.ToString();
                            equipo++;
                            lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                            break;
                        default:
                            break;
                    }
            }
            else
            {
                switch (comboBox1.SelectedItem)
                {
                    case "Ganó":

                        if (partido >= objTorneo.numero_equipos - 1)
                        {
                            if (partido == objTorneo.numero_equipos - 1)
                            {
                                objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_ganar.ToString();
                                equipo++;
                                partido = 1;
                                if (equipo >= objTorneo.puntaje_partido.GetLength(0))
                                {
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                        if (x == 0)
                                        {
                                            dataGridView1.Columns.Add("nombre", "Nombre");
                                            for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                            {
                                                dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                            }
                                        }
                                        for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            row[y] = objTorneo.puntaje_partido[x, y];
                                        }
                                        dataGridView1.Rows.Add(row);
                                    }
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        int total = 0;
                                        if (x == 0)
                                        {
                                            totalarr = new string[objTorneo.numero_equipos];
                                            totalInt = new int[objTorneo.numero_equipos];
                                            for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                            {
                                                dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                            }
                                        }

                                        for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                        }
                                        totalarr[x] = total.ToString();
                                    }
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        totalInt[i] = Convert.ToInt32(totalarr[i]);
                                    }
                                    campeon = totalInt.Max();
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        if (totalInt[i] == campeon)
                                        {
                                            comboBox1.Enabled = false;
                                            btnNext.Enabled = false;
                                            lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0] + " con " + campeon + " Puntos";
                                            using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                            {

                                                Outputfile.WriteLine(lblEquipoGanador.Text);

                                            }
                                        }
                                    }
                                    dataGridView2.Rows.Add(totalarr);
                                }
                                else
                                    lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                                lblnumPartido.Text = partido.ToString();
                            }
                            else
                            {
                                foreach (var item in objTorneo.puntaje_partido)
                                {
                                    MessageBox.Show(item);
                                }
                            }

                        }
                        else
                        {
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_ganar.ToString();
                            partido++;
                            lblnumPartido.Text = partido.ToString();
                        }

                        break;
                    case "Perdió":

                        if (partido >= objTorneo.numero_equipos - 1)
                        {
                            if (partido == objTorneo.numero_equipos - 1)
                            {
                                objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_perder.ToString();
                                equipo++;
                                partido = 1;
                                if (equipo >= objTorneo.puntaje_partido.GetLength(0))
                                {
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                        if (x == 0)
                                        {
                                            dataGridView1.Columns.Add("nombre", "Nombre");
                                            for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                            {
                                                dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                            }
                                        }
                                        for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            row[y] = objTorneo.puntaje_partido[x, y];
                                        }
                                        dataGridView1.Rows.Add(row);
                                    }
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        int total = 0;
                                        if (x == 0)
                                        {
                                            totalarr = new string[objTorneo.numero_equipos];
                                            totalInt = new int[objTorneo.numero_equipos];
                                            for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                            {
                                                dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                            }
                                        }

                                        for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                        }
                                        totalarr[x] = total.ToString();
                                    }
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        totalInt[i] = Convert.ToInt32(totalarr[i]);
                                    }
                                    campeon = totalInt.Max();
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        if (totalInt[i] == campeon)
                                        {
                                            comboBox1.Enabled = false;
                                            btnNext.Enabled = false;
                                            lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0] + " con " + campeon + " Puntos";
                                            using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                            {

                                                Outputfile.WriteLine(lblEquipoGanador.Text);

                                            }
                                        }
                                    }
                                    dataGridView2.Rows.Add(totalarr);
                                }
                                else
                                    lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                                lblnumPartido.Text = partido.ToString();
                            }
                            else
                            {
                                foreach (var item in objTorneo.puntaje_partido)
                                {
                                    MessageBox.Show(item);
                                }
                            }

                        }
                        else
                        {
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_perder.ToString();
                            partido++;
                            lblnumPartido.Text = partido.ToString();
                        }

                        break;
                    case "Empató":

                        if (partido >= objTorneo.numero_equipos - 1)
                        {
                            if (partido == objTorneo.numero_equipos - 1)
                            {
                                objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_empatar.ToString();
                                equipo++;
                                partido = 1;
                                if (equipo >= objTorneo.puntaje_partido.GetLength(0))
                                {
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        string[] row = new string[objTorneo.puntaje_partido.GetLength(1)];
                                        if (x == 0)
                                        {
                                            dataGridView1.Columns.Add("nombre", "Nombre");
                                            for (int i = 1; i < objTorneo.puntaje_partido.GetLength(1); i++)
                                            {
                                                dataGridView1.Columns.Add("partido" + i, "Partido " + i);
                                            }
                                        }
                                        for (int y = 0; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            row[y] = objTorneo.puntaje_partido[x, y];
                                        }
                                        dataGridView1.Rows.Add(row);
                                    }
                                    for (int x = 0; x < objTorneo.puntaje_partido.GetLength(0); x += 1)
                                    {
                                        int total = 0;
                                        if (x == 0)
                                        {
                                            totalarr = new string[objTorneo.numero_equipos];
                                            totalInt = new int[objTorneo.numero_equipos];
                                            for (int i = 0; i < objTorneo.puntaje_partido.GetLength(0); i++)
                                            {
                                                dataGridView2.Columns.Add("nombre" + i, objTorneo.puntaje_partido[i, 0]);
                                            }
                                        }

                                        for (int y = 1; y < objTorneo.puntaje_partido.GetLength(1); y += 1)
                                        {
                                            total = total + Convert.ToInt32(objTorneo.puntaje_partido[x, y]);
                                        }
                                        totalarr[x] = total.ToString();
                                    }
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        totalInt[i] = Convert.ToInt32(totalarr[i]);
                                    }
                                    campeon = totalInt.Max();
                                    for (int i = 0; i < totalarr.Length; i++)
                                    {
                                        if (totalInt[i] == campeon)
                                        {
                                            comboBox1.Enabled = false;
                                            btnNext.Enabled = false;
                                            lblEquipoGanador.Text = objTorneo.puntaje_partido[i, 0] + " con " + campeon + " Puntos";
                                            using (StreamWriter Outputfile = new StreamWriter("arhivotorneo.txt"))
                                            {

                                                Outputfile.WriteLine(lblEquipoGanador.Text);

                                            }
                                        }
                                    }
                                    dataGridView2.Rows.Add(totalarr);

                                }
                                else
                                    lblNombre2.Text = objTorneo.puntaje_partido[equipo, 0];
                                lblnumPartido.Text = partido.ToString();
                            }
                            else
                            {
                                foreach (var item in objTorneo.puntaje_partido)
                                {
                                    MessageBox.Show(item);
                                }
                            }

                        }
                        else
                        {
                            objTorneo.puntaje_partido[equipo, partido] = objTorneo.Puntos_empatar.ToString();
                            partido++;
                            lblnumPartido.Text = partido.ToString();
                        }

                        break;
                    default:
                        MessageBox.Show("Seleccione un resultado");
                        break;
                }
            }

        }
    }
}


