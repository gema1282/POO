﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PaisesArchivo
{
    public partial class Form1 : Form
    {
        Paises objPaises = new Paises();
        TextWriter archivo;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");

            if (txtNombre.Text == "")
            {
                errorProvider1.SetError(txtNombre, "Debe introducir el nombre del país");
                txtNombre.Focus();
                return;
            }
            errorProvider1.SetError(txtNombre, "");

            if (txtPoblacion.Text == "")
            {
                errorProvider1.SetError(txtPoblacion, "Debe introducir la cantidad de población");
                txtPoblacion.Focus();
                return;
            }
            errorProvider1.SetError(txtPoblacion, "");

            if (txtColor1.Text == "")
            {
                errorProvider1.SetError(txtColor1, "Debe introducir el primer color de la bandera");
                txtColor1.Focus();
                return;
            }
            errorProvider1.SetError(txtColor2, "");

            if (txtColor1.Text == "")
            {
                errorProvider1.SetError(txtColor2, "Debe introducir el segundo color de la bandera");
                txtColor2.Focus();
                return;
            }
            errorProvider1.SetError(txtColor2, "");

            if (txtColor3.Text == "")
            {
                errorProvider1.SetError(txtColor3, "Debe introducir el tercer color de la bandera");
                txtColor1.Focus();
                return;
            }
            errorProvider1.SetError(txtColor3, "");

            objPaises.Nombre = txtNombre.Text;
            objPaises.Poblacion = Convert.ToInt32(txtPoblacion.Text);
            objPaises.Idioma = txtIdioma.Text;

            objPaises.ColBandera = new string[3];

            objPaises.ColBandera[0] = txtColor1.Text;
            objPaises.ColBandera[1] = txtColor2.Text;
            objPaises.ColBandera[2] = txtColor3.Text;

            archivo.WriteLine(objPaises.Nombre + "\n" + objPaises.Poblacion + "\n" + objPaises.Idioma + "\n" + objPaises.ColBandera[0] + "\n" + objPaises.ColBandera[1] + "\n" + objPaises.ColBandera[2]);
            archivo.Close();

            MessageBox.Show("\n" + txtNombre.Text + "\n" + txtPoblacion.Text + "\n" + txtIdioma.Text + "\n" + txtColor1.Text + "\n" + txtColor2.Text + "\n" + txtColor3.Text, "Datos del Pais");

            txtNombre.Text = "";
            txtPoblacion.Text = "";
            txtIdioma.Text = "";
            txtColor1.Text = "";
            txtColor2.Text = "";
            txtColor3.Text = "";
        }
    }
}
