﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlcanciaArchivo
{
    public partial class Form1 : Form
    {
        claseArregloArchivo objArreglo = new claseArregloArchivo();
        TextWriter archivo;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            objArreglo.ahorrar(decimal.Parse(txtDinero.Text));
            lblArreglo.Text = objArreglo.imprimirArreglo();
            txtDinero.Text = "0.0";
        }

        private void btnRomper_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");

            lblTextoTotal.Visible = true;
            lblTotal.Visible = true;
            lblTotal.Text = objArreglo.contarAhorros().ToString();
            lblArreglo.Text = lblArreglo.Text + "= " + lblTotal.Text;


            archivo.WriteLine(objArreglo.imprimirArreglo());
            archivo.Close();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            lblTextoTotal.Visible = false;
            lblTotal.Visible = false;
            lblArreglo.Text = "[ ]";
            txtDinero.Text = "0.0";
        }
    }
}
