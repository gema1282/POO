﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sumaMatrizArchivo
{
    public partial class Form1 : Form
    {
        claseMatriz objMatriz = new claseMatriz();
        TextWriter archivo;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            archivo = new StreamWriter("archivo.txt");

            objMatriz.crearMatriz(int.Parse(nUDTamano.Value.ToString()));
            btnCrear.Enabled = false;
            nUDTamano.Enabled = false;

            objMatriz.registrar();
            btnObtenerSumas.Enabled = true;
            txtMatriz.Text = objMatriz.imprimirArreglo();

            archivo.WriteLine(objMatriz.imprimirArreglo());
            archivo.Close();
        }

        private void btnObtenerSumas_Click(object sender, EventArgs e)
        {
            //Suma columnas
            for (int i = 0; i < int.Parse(nUDTamano.Value.ToString()); i++)
            {
                int suma = 0;
                for (int j = 0; j < int.Parse(nUDTamano.Value.ToString()); j++)
                {
                    suma += objMatriz.Matriz[j, i];
                }
                txtSumacolumna.Text += "Culumna " + (i + 1) + " = " + suma;
                txtSumacolumna.Text += "\r\n";
            }

            //Suma Filas
            for (int i = 0; i < int.Parse(nUDTamano.Value.ToString()); i++)
            {
                int suma = 0;
                for (int j = 0; j < int.Parse(nUDTamano.Value.ToString()); j++)
                {
                    suma += objMatriz.Matriz[i, j];
                }
                txtSumafila.Text += "Fila " + (i + 1) + " = " + suma;
                txtSumafila.Text += "\r\n";
            }

            //Suma diagonales
            int sumaDiagonal1 = 0;
            for (int i = 0; i < int.Parse(nUDTamano.Value.ToString()); i++)
            {
                for (int j = i; j <= i; j++)
                {
                    sumaDiagonal1 += objMatriz.Matriz[i, j];
                }
            }
            txtSumaDiagonal.Text += "Diagonal \\ = " + sumaDiagonal1;
            txtSumaDiagonal.Text += "\r\n";

            int sumaDiagonal2 = 0;
            for (int i = 0; i < int.Parse(nUDTamano.Value.ToString()); i++)
            {
                for (int j = int.Parse(nUDTamano.Value.ToString()) - i - 1; j == int.Parse(nUDTamano.Value.ToString()) - i - 1; j++)
                {
                    sumaDiagonal2 += objMatriz.Matriz[j, i];
                }
            }
            txtSumaDiagonal.Text += "Diagonal / = " + sumaDiagonal2;
            txtSumaDiagonal.Text += "\r\n";
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtSumacolumna.Text = "";
            txtSumaDiagonal.Text = "";
            txtSumafila.Text = "";
            txtMatriz.Text = "";
            nUDTamano.Value = 2;
            nUDTamano.Enabled = true;
            btnCrear.Enabled = true;
            btnObtenerSumas.Enabled = false;
        }
    }
}
