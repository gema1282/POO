﻿using InputKey;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sumaMatrizArchivo
{
    class claseMatriz
    {
        static int[,] matriz;
        int tamaño;
        int[] sumaFilas;
        int[] sumacolumnas;
        int[] sumaDiagonales;

        public int Tamaño { get => tamaño; set => tamaño = value; }
        public int[,] Matriz { get => matriz; set => matriz = value; }

        public void crearMatriz(int tamaño)
        {
            Matriz = new int[tamaño, tamaño];
            this.Tamaño = tamaño;
        }

        public void registrar()
        {
            for (int i = 0; i < this.Tamaño; i++)
            {
                for (int j = 0; j < this.Tamaño; j++)
                {
                    int valor = int.Parse(InputDialog.mostrar("Ingresa el valor de la fila: " + (i + 1) + "\r\n y la columna: " + (j + 1)));
                    Matriz[i, j] = valor;
                }
            }
        }

        public string imprimirArreglo()
        {
            string texto = "";
            for (int i = 0; i < this.Tamaño; i++)
            {
                for (int j = 0; j < this.Tamaño; j++)
                {
                    texto = texto + "   " + Matriz[i, j] + "    ";
                }
                texto = texto + "\r\n";
            }
            return texto;
        }
    }
}
