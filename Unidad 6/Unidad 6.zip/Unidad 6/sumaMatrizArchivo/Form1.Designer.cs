﻿namespace sumaMatrizArchivo
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnObtenerSumas = new System.Windows.Forms.Button();
            this.txtSumaDiagonal = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSumafila = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSumacolumna = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCrear = new System.Windows.Forms.Button();
            this.txtMatriz = new System.Windows.Forms.TextBox();
            this.nUDTamano = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nUDTamano)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(484, 415);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 53;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnObtenerSumas
            // 
            this.btnObtenerSumas.Enabled = false;
            this.btnObtenerSumas.Location = new System.Drawing.Point(416, 295);
            this.btnObtenerSumas.Name = "btnObtenerSumas";
            this.btnObtenerSumas.Size = new System.Drawing.Size(106, 23);
            this.btnObtenerSumas.TabIndex = 52;
            this.btnObtenerSumas.Text = "Obtener sumas";
            this.btnObtenerSumas.UseVisualStyleBackColor = true;
            this.btnObtenerSumas.Click += new System.EventHandler(this.btnObtenerSumas_Click);
            // 
            // txtSumaDiagonal
            // 
            this.txtSumaDiagonal.Enabled = false;
            this.txtSumaDiagonal.Location = new System.Drawing.Point(292, 321);
            this.txtSumaDiagonal.Multiline = true;
            this.txtSumaDiagonal.Name = "txtSumaDiagonal";
            this.txtSumaDiagonal.Size = new System.Drawing.Size(82, 117);
            this.txtSumaDiagonal.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(289, 305);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 50;
            this.label4.Text = "Suma diagonales:";
            // 
            // txtSumafila
            // 
            this.txtSumafila.Enabled = false;
            this.txtSumafila.Location = new System.Drawing.Point(173, 321);
            this.txtSumafila.Multiline = true;
            this.txtSumafila.Name = "txtSumafila";
            this.txtSumafila.Size = new System.Drawing.Size(82, 117);
            this.txtSumafila.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(170, 305);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "Suma filas:";
            // 
            // txtSumacolumna
            // 
            this.txtSumacolumna.Enabled = false;
            this.txtSumacolumna.Location = new System.Drawing.Point(45, 321);
            this.txtSumacolumna.Multiline = true;
            this.txtSumacolumna.Name = "txtSumacolumna";
            this.txtSumacolumna.Size = new System.Drawing.Size(82, 117);
            this.txtSumacolumna.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 305);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "Suma columnas:";
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(416, 37);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(103, 47);
            this.btnCrear.TabIndex = 45;
            this.btnCrear.Text = "Crear Matriz";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // txtMatriz
            // 
            this.txtMatriz.Enabled = false;
            this.txtMatriz.Location = new System.Drawing.Point(45, 51);
            this.txtMatriz.Multiline = true;
            this.txtMatriz.Name = "txtMatriz";
            this.txtMatriz.Size = new System.Drawing.Size(329, 232);
            this.txtMatriz.TabIndex = 44;
            // 
            // nUDTamano
            // 
            this.nUDTamano.Location = new System.Drawing.Point(232, 11);
            this.nUDTamano.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.nUDTamano.Name = "nUDTamano";
            this.nUDTamano.Size = new System.Drawing.Size(120, 20);
            this.nUDTamano.TabIndex = 43;
            this.nUDTamano.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "Ingresa el tamaño del arreglo bidimensional:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 450);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnObtenerSumas);
            this.Controls.Add(this.txtSumaDiagonal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSumafila);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSumacolumna);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.txtMatriz);
            this.Controls.Add(this.nUDTamano);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nUDTamano)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnObtenerSumas;
        private System.Windows.Forms.TextBox txtSumaDiagonal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSumafila;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSumacolumna;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.TextBox txtMatriz;
        private System.Windows.Forms.NumericUpDown nUDTamano;
        private System.Windows.Forms.Label label1;
    }
}

