﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cerveceriaArchivo
{
    class claseCervezas
    {
        string[,] cervezas = new string[8, 4];
        int contador = 1;

        public int Contador { get => contador; set => contador = value; }

        public void registrar(string nombreCerveza, string chica, string mediana, string grande)
        {
            if (Contador < 8)
            {
                cervezas[0, 0] = "Nombre/Tamaño";
                cervezas[0, 1] = "Chica";
                cervezas[0, 2] = "Mediana";
                cervezas[0, 3] = "Grande";

                cervezas[Contador, 0] = nombreCerveza;
                cervezas[Contador, 1] = chica;
                cervezas[Contador, 2] = mediana;
                cervezas[Contador, 3] = grande;

                contador++;
            }
        }

        public string imprimirArreglo()
        {
            string texto = "";
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (i == 0)
                    {
                        texto = texto + "   " + cervezas[i, j] + "       ";
                    }
                    else
                    {
                        texto = texto + "       " + cervezas[i, j] + "            ";
                    }
                }
                texto = texto + "\r\n";
            }
            return texto;
        }
    }
}
