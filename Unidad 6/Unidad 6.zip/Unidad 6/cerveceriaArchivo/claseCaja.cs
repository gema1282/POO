﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cerveceriaArchivo
{
    class claseCaja
    {
        decimal[] caja = new decimal[0];
        int contador = 0;
        decimal total = 0;

        public void venta(decimal cantidad)
        {
            Array.Resize(ref caja, caja.Length + 1);
            caja[contador] = cantidad;
            contador++;
        }

        public decimal contarVentas()
        {
            for (int i = 0; i < caja.Length; i++)
            {
                total = total + caja[i];
            }
            return total;
        }

        public string imprimirArreglo()
        {
            string texto = "";
            for (int i = 0; i < caja.Length; i++)
            {
                texto = texto + "[ " + caja[i] + " ] ";
            }
            return texto;
        }
    }
}
