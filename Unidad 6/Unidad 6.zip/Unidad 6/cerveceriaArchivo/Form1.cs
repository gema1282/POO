﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace cerveceriaArchivo
{
    public partial class Form1 : Form
    {
        claseCervezas objCervezas = new claseCervezas();
        claseCaja objCaja = new claseCaja();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            objCervezas.registrar(txtCerveza.Text, txtChico.Text, txtMediano.Text, txtGrande.Text);
            lblCantidad.Text = (objCervezas.Contador - 1).ToString();
            txtCerveza.Text = "";
            txtChico.Text = "0.0";
            txtMediano.Text = "0.0";
            txtGrande.Text = "0.0";
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            txtMenu.Text = objCervezas.imprimirArreglo();
        }

        private void btnCaja_Click(object sender, EventArgs e)
        {
            objCaja.venta(decimal.Parse(txtVenta.Text));
            lblArreloUnidimensional.Text = objCaja.imprimirArreglo();

            using (StreamWriter Outputfile = new StreamWriter("arhivogema.txt"))
            {

                Outputfile.WriteLine(lblArreloUnidimensional.Text);

            }
            txtVenta.Text = "0.0";
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            lblArreloUnidimensional.Text = lblArreloUnidimensional.Text + "= " + objCaja.contarVentas().ToString();
        }
    }
}
