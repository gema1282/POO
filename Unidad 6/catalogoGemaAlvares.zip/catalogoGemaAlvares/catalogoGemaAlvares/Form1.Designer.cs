﻿namespace catalogoGemaAlvares
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.miPrimerProyectoEnConsolaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miPrimerProyectoEnFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidad2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.areaPerimetroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asistenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calificacionesAlumnosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.casetaAutopistaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.electricidadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embotelladoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fechaNacimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gradosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vacacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidad6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empleadosRestauranteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figurasGeometricasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interfacesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehiculosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unida6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alcanciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alumnoDocenteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerveceriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.datosAlumnosDocentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejemplo1ArreglosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejemplo2ArreglosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejemplo3ArreglosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejemplo1PropuestoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miPrimerArraylistToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.numeroMayorMenorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paisesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sumaMatrizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unidad4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alcanciaArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alumnoDocenteArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional1ArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional2ArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bidimensional3ArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerveceriaArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.datosAlumnosDocentesArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miPrimerArraylistToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.numerosMayorMenorArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paisesArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sumaMatrizArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.torneoArchivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.unidad2ToolStripMenuItem,
            this.unidad6ToolStripMenuItem,
            this.unida6ToolStripMenuItem,
            this.unidad4ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(771, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miPrimerProyectoEnConsolaToolStripMenuItem,
            this.miPrimerProyectoEnFormToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(66, 20);
            this.toolStripMenuItem1.Text = "Unidad 1";
            // 
            // miPrimerProyectoEnConsolaToolStripMenuItem
            // 
            this.miPrimerProyectoEnConsolaToolStripMenuItem.Name = "miPrimerProyectoEnConsolaToolStripMenuItem";
            this.miPrimerProyectoEnConsolaToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.miPrimerProyectoEnConsolaToolStripMenuItem.Text = "Mi primer proyecto en consola";
            this.miPrimerProyectoEnConsolaToolStripMenuItem.Click += new System.EventHandler(this.miPrimerProyectoEnConsolaToolStripMenuItem_Click);
            // 
            // miPrimerProyectoEnFormToolStripMenuItem
            // 
            this.miPrimerProyectoEnFormToolStripMenuItem.Name = "miPrimerProyectoEnFormToolStripMenuItem";
            this.miPrimerProyectoEnFormToolStripMenuItem.Size = new System.Drawing.Size(236, 22);
            this.miPrimerProyectoEnFormToolStripMenuItem.Text = "Mi primer proyecto en form";
            this.miPrimerProyectoEnFormToolStripMenuItem.Click += new System.EventHandler(this.miPrimerProyectoEnFormToolStripMenuItem_Click);
            // 
            // unidad2ToolStripMenuItem
            // 
            this.unidad2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.areaPerimetroToolStripMenuItem,
            this.asistenteToolStripMenuItem,
            this.calificacionesAlumnosToolStripMenuItem,
            this.casetaAutopistaToolStripMenuItem,
            this.electricidadToolStripMenuItem,
            this.embotelladoraToolStripMenuItem,
            this.fechaNacimientoToolStripMenuItem,
            this.gradosToolStripMenuItem,
            this.vacacionesToolStripMenuItem});
            this.unidad2ToolStripMenuItem.Name = "unidad2ToolStripMenuItem";
            this.unidad2ToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.unidad2ToolStripMenuItem.Text = "Unidad 2 y 3";
            // 
            // areaPerimetroToolStripMenuItem
            // 
            this.areaPerimetroToolStripMenuItem.Name = "areaPerimetroToolStripMenuItem";
            this.areaPerimetroToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.areaPerimetroToolStripMenuItem.Text = "Area Perimetro ";
            this.areaPerimetroToolStripMenuItem.Click += new System.EventHandler(this.areaPerimetroToolStripMenuItem_Click);
            // 
            // asistenteToolStripMenuItem
            // 
            this.asistenteToolStripMenuItem.Name = "asistenteToolStripMenuItem";
            this.asistenteToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.asistenteToolStripMenuItem.Text = "Asistente";
            this.asistenteToolStripMenuItem.Click += new System.EventHandler(this.asistenteToolStripMenuItem_Click);
            // 
            // calificacionesAlumnosToolStripMenuItem
            // 
            this.calificacionesAlumnosToolStripMenuItem.Name = "calificacionesAlumnosToolStripMenuItem";
            this.calificacionesAlumnosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.calificacionesAlumnosToolStripMenuItem.Text = "Calificaciones Alumnos";
            this.calificacionesAlumnosToolStripMenuItem.Click += new System.EventHandler(this.calificacionesAlumnosToolStripMenuItem_Click);
            // 
            // casetaAutopistaToolStripMenuItem
            // 
            this.casetaAutopistaToolStripMenuItem.Name = "casetaAutopistaToolStripMenuItem";
            this.casetaAutopistaToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.casetaAutopistaToolStripMenuItem.Text = "Caseta Autopista";
            this.casetaAutopistaToolStripMenuItem.Click += new System.EventHandler(this.casetaAutopistaToolStripMenuItem_Click);
            // 
            // electricidadToolStripMenuItem
            // 
            this.electricidadToolStripMenuItem.Name = "electricidadToolStripMenuItem";
            this.electricidadToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.electricidadToolStripMenuItem.Text = "Electricidad";
            this.electricidadToolStripMenuItem.Click += new System.EventHandler(this.electricidadToolStripMenuItem_Click);
            // 
            // embotelladoraToolStripMenuItem
            // 
            this.embotelladoraToolStripMenuItem.Name = "embotelladoraToolStripMenuItem";
            this.embotelladoraToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.embotelladoraToolStripMenuItem.Text = "Embotelladora";
            this.embotelladoraToolStripMenuItem.Click += new System.EventHandler(this.embotelladoraToolStripMenuItem_Click);
            // 
            // fechaNacimientoToolStripMenuItem
            // 
            this.fechaNacimientoToolStripMenuItem.Name = "fechaNacimientoToolStripMenuItem";
            this.fechaNacimientoToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.fechaNacimientoToolStripMenuItem.Text = "Fecha Nacimiento";
            this.fechaNacimientoToolStripMenuItem.Click += new System.EventHandler(this.fechaNacimientoToolStripMenuItem_Click);
            // 
            // gradosToolStripMenuItem
            // 
            this.gradosToolStripMenuItem.Name = "gradosToolStripMenuItem";
            this.gradosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.gradosToolStripMenuItem.Text = "Grados ";
            this.gradosToolStripMenuItem.Click += new System.EventHandler(this.gradosToolStripMenuItem_Click);
            // 
            // vacacionesToolStripMenuItem
            // 
            this.vacacionesToolStripMenuItem.Name = "vacacionesToolStripMenuItem";
            this.vacacionesToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.vacacionesToolStripMenuItem.Text = "Vacaciones";
            this.vacacionesToolStripMenuItem.Click += new System.EventHandler(this.vacacionesToolStripMenuItem_Click);
            // 
            // unidad6ToolStripMenuItem
            // 
            this.unidad6ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empleadosRestauranteToolStripMenuItem,
            this.figurasGeometricasToolStripMenuItem,
            this.interfacesToolStripMenuItem,
            this.operacionToolStripMenuItem,
            this.vehiculosToolStripMenuItem});
            this.unidad6ToolStripMenuItem.Name = "unidad6ToolStripMenuItem";
            this.unidad6ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.unidad6ToolStripMenuItem.Text = "Unidad 4";
            // 
            // empleadosRestauranteToolStripMenuItem
            // 
            this.empleadosRestauranteToolStripMenuItem.Name = "empleadosRestauranteToolStripMenuItem";
            this.empleadosRestauranteToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.empleadosRestauranteToolStripMenuItem.Text = "Empleados Restaurante";
            this.empleadosRestauranteToolStripMenuItem.Click += new System.EventHandler(this.empleadosRestauranteToolStripMenuItem_Click);
            // 
            // figurasGeometricasToolStripMenuItem
            // 
            this.figurasGeometricasToolStripMenuItem.Name = "figurasGeometricasToolStripMenuItem";
            this.figurasGeometricasToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.figurasGeometricasToolStripMenuItem.Text = "Figuras Geometricas";
            this.figurasGeometricasToolStripMenuItem.Click += new System.EventHandler(this.figurasGeometricasToolStripMenuItem_Click);
            // 
            // interfacesToolStripMenuItem
            // 
            this.interfacesToolStripMenuItem.Name = "interfacesToolStripMenuItem";
            this.interfacesToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.interfacesToolStripMenuItem.Text = "Interfaces";
            this.interfacesToolStripMenuItem.Click += new System.EventHandler(this.interfacesToolStripMenuItem_Click);
            // 
            // operacionToolStripMenuItem
            // 
            this.operacionToolStripMenuItem.Name = "operacionToolStripMenuItem";
            this.operacionToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.operacionToolStripMenuItem.Text = "Operacion ";
            this.operacionToolStripMenuItem.Click += new System.EventHandler(this.operacionToolStripMenuItem_Click);
            // 
            // vehiculosToolStripMenuItem
            // 
            this.vehiculosToolStripMenuItem.Name = "vehiculosToolStripMenuItem";
            this.vehiculosToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.vehiculosToolStripMenuItem.Text = "Vehiculos";
            this.vehiculosToolStripMenuItem.Click += new System.EventHandler(this.vehiculosToolStripMenuItem_Click);
            // 
            // unida6ToolStripMenuItem
            // 
            this.unida6ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alcanciaToolStripMenuItem,
            this.alumnoDocenteToolStripMenuItem,
            this.bidimensional1ToolStripMenuItem,
            this.bidimensional2ToolStripMenuItem,
            this.bidimensional3ToolStripMenuItem,
            this.cerveceriaToolStripMenuItem,
            this.datosAlumnosDocentesToolStripMenuItem,
            this.ejemplo1ArreglosToolStripMenuItem,
            this.ejemplo2ArreglosToolStripMenuItem,
            this.ejemplo3ArreglosToolStripMenuItem,
            this.ejemplo1PropuestoToolStripMenuItem,
            this.miPrimerArraylistToolStripMenuItem,
            this.numeroMayorMenorToolStripMenuItem,
            this.paisesToolStripMenuItem,
            this.sumaMatrizToolStripMenuItem});
            this.unida6ToolStripMenuItem.Name = "unida6ToolStripMenuItem";
            this.unida6ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.unida6ToolStripMenuItem.Text = "Unidad 5";
            // 
            // alcanciaToolStripMenuItem
            // 
            this.alcanciaToolStripMenuItem.Name = "alcanciaToolStripMenuItem";
            this.alcanciaToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.alcanciaToolStripMenuItem.Text = "Alcancia ";
            this.alcanciaToolStripMenuItem.Click += new System.EventHandler(this.alcanciaToolStripMenuItem_Click);
            // 
            // alumnoDocenteToolStripMenuItem
            // 
            this.alumnoDocenteToolStripMenuItem.Name = "alumnoDocenteToolStripMenuItem";
            this.alumnoDocenteToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.alumnoDocenteToolStripMenuItem.Text = "Alumno Docente";
            this.alumnoDocenteToolStripMenuItem.Click += new System.EventHandler(this.alumnoDocenteToolStripMenuItem_Click);
            // 
            // bidimensional1ToolStripMenuItem
            // 
            this.bidimensional1ToolStripMenuItem.Name = "bidimensional1ToolStripMenuItem";
            this.bidimensional1ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.bidimensional1ToolStripMenuItem.Text = "Bidimensional 1";
            this.bidimensional1ToolStripMenuItem.Click += new System.EventHandler(this.bidimensional1ToolStripMenuItem_Click);
            // 
            // bidimensional2ToolStripMenuItem
            // 
            this.bidimensional2ToolStripMenuItem.Name = "bidimensional2ToolStripMenuItem";
            this.bidimensional2ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.bidimensional2ToolStripMenuItem.Text = "Bidimensional 2";
            this.bidimensional2ToolStripMenuItem.Click += new System.EventHandler(this.bidimensional2ToolStripMenuItem_Click);
            // 
            // bidimensional3ToolStripMenuItem
            // 
            this.bidimensional3ToolStripMenuItem.Name = "bidimensional3ToolStripMenuItem";
            this.bidimensional3ToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.bidimensional3ToolStripMenuItem.Text = "Bidimensional 3";
            this.bidimensional3ToolStripMenuItem.Click += new System.EventHandler(this.bidimensional3ToolStripMenuItem_Click);
            // 
            // cerveceriaToolStripMenuItem
            // 
            this.cerveceriaToolStripMenuItem.Name = "cerveceriaToolStripMenuItem";
            this.cerveceriaToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.cerveceriaToolStripMenuItem.Text = "Cerveceria ";
            this.cerveceriaToolStripMenuItem.Click += new System.EventHandler(this.cerveceriaToolStripMenuItem_Click);
            // 
            // datosAlumnosDocentesToolStripMenuItem
            // 
            this.datosAlumnosDocentesToolStripMenuItem.Name = "datosAlumnosDocentesToolStripMenuItem";
            this.datosAlumnosDocentesToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.datosAlumnosDocentesToolStripMenuItem.Text = "Datos Alumnos Docentes";
            this.datosAlumnosDocentesToolStripMenuItem.Click += new System.EventHandler(this.datosAlumnosDocentesToolStripMenuItem_Click);
            // 
            // ejemplo1ArreglosToolStripMenuItem
            // 
            this.ejemplo1ArreglosToolStripMenuItem.Name = "ejemplo1ArreglosToolStripMenuItem";
            this.ejemplo1ArreglosToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.ejemplo1ArreglosToolStripMenuItem.Text = "Ejemplo 1 Arreglos";
            this.ejemplo1ArreglosToolStripMenuItem.Click += new System.EventHandler(this.ejemplo1ArreglosToolStripMenuItem_Click);
            // 
            // ejemplo2ArreglosToolStripMenuItem
            // 
            this.ejemplo2ArreglosToolStripMenuItem.Name = "ejemplo2ArreglosToolStripMenuItem";
            this.ejemplo2ArreglosToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.ejemplo2ArreglosToolStripMenuItem.Text = "Ejemplo 2 Arreglos";
            this.ejemplo2ArreglosToolStripMenuItem.Click += new System.EventHandler(this.ejemplo2ArreglosToolStripMenuItem_Click);
            // 
            // ejemplo3ArreglosToolStripMenuItem
            // 
            this.ejemplo3ArreglosToolStripMenuItem.Name = "ejemplo3ArreglosToolStripMenuItem";
            this.ejemplo3ArreglosToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.ejemplo3ArreglosToolStripMenuItem.Text = "Ejemplo 3 Arreglos";
            this.ejemplo3ArreglosToolStripMenuItem.Click += new System.EventHandler(this.ejemplo3ArreglosToolStripMenuItem_Click);
            // 
            // ejemplo1PropuestoToolStripMenuItem
            // 
            this.ejemplo1PropuestoToolStripMenuItem.Name = "ejemplo1PropuestoToolStripMenuItem";
            this.ejemplo1PropuestoToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.ejemplo1PropuestoToolStripMenuItem.Text = "Ejemplo 1 propuesto";
            this.ejemplo1PropuestoToolStripMenuItem.Click += new System.EventHandler(this.ejemplo1PropuestoToolStripMenuItem_Click);
            // 
            // miPrimerArraylistToolStripMenuItem
            // 
            this.miPrimerArraylistToolStripMenuItem.Name = "miPrimerArraylistToolStripMenuItem";
            this.miPrimerArraylistToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.miPrimerArraylistToolStripMenuItem.Text = "Mi primer Arraylist";
            this.miPrimerArraylistToolStripMenuItem.Click += new System.EventHandler(this.miPrimerArraylistToolStripMenuItem_Click);
            // 
            // numeroMayorMenorToolStripMenuItem
            // 
            this.numeroMayorMenorToolStripMenuItem.Name = "numeroMayorMenorToolStripMenuItem";
            this.numeroMayorMenorToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.numeroMayorMenorToolStripMenuItem.Text = "Numero Mayor Menor";
            this.numeroMayorMenorToolStripMenuItem.Click += new System.EventHandler(this.numeroMayorMenorToolStripMenuItem_Click);
            // 
            // paisesToolStripMenuItem
            // 
            this.paisesToolStripMenuItem.Name = "paisesToolStripMenuItem";
            this.paisesToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.paisesToolStripMenuItem.Text = "Paises";
            this.paisesToolStripMenuItem.Click += new System.EventHandler(this.paisesToolStripMenuItem_Click);
            // 
            // sumaMatrizToolStripMenuItem
            // 
            this.sumaMatrizToolStripMenuItem.Name = "sumaMatrizToolStripMenuItem";
            this.sumaMatrizToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.sumaMatrizToolStripMenuItem.Text = "Suma Matriz";
            this.sumaMatrizToolStripMenuItem.Click += new System.EventHandler(this.sumaMatrizToolStripMenuItem_Click);
            // 
            // unidad4ToolStripMenuItem
            // 
            this.unidad4ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alcanciaArchivoToolStripMenuItem,
            this.alumnoDocenteArchivoToolStripMenuItem,
            this.bidimensional1ArchivoToolStripMenuItem,
            this.bidimensional2ArchivoToolStripMenuItem,
            this.bidimensional3ArchivoToolStripMenuItem,
            this.cerveceriaArchivoToolStripMenuItem,
            this.datosAlumnosDocentesArchivoToolStripMenuItem,
            this.miPrimerArraylistToolStripMenuItem1,
            this.numerosMayorMenorArchivoToolStripMenuItem,
            this.paisesArchivoToolStripMenuItem,
            this.sumaMatrizArchivoToolStripMenuItem,
            this.torneoArchivoToolStripMenuItem});
            this.unidad4ToolStripMenuItem.Name = "unidad4ToolStripMenuItem";
            this.unidad4ToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.unidad4ToolStripMenuItem.Text = "Unidad 6";
            // 
            // alcanciaArchivoToolStripMenuItem
            // 
            this.alcanciaArchivoToolStripMenuItem.Name = "alcanciaArchivoToolStripMenuItem";
            this.alcanciaArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.alcanciaArchivoToolStripMenuItem.Text = "Alcancia (Archivo)";
            this.alcanciaArchivoToolStripMenuItem.Click += new System.EventHandler(this.alcanciaArchivoToolStripMenuItem_Click);
            // 
            // alumnoDocenteArchivoToolStripMenuItem
            // 
            this.alumnoDocenteArchivoToolStripMenuItem.Name = "alumnoDocenteArchivoToolStripMenuItem";
            this.alumnoDocenteArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.alumnoDocenteArchivoToolStripMenuItem.Text = "Alumno Docente (Archivo)";
            this.alumnoDocenteArchivoToolStripMenuItem.Click += new System.EventHandler(this.alumnoDocenteArchivoToolStripMenuItem_Click);
            // 
            // bidimensional1ArchivoToolStripMenuItem
            // 
            this.bidimensional1ArchivoToolStripMenuItem.Name = "bidimensional1ArchivoToolStripMenuItem";
            this.bidimensional1ArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.bidimensional1ArchivoToolStripMenuItem.Text = "Bidimensional 1 (Archivo)";
            this.bidimensional1ArchivoToolStripMenuItem.Click += new System.EventHandler(this.bidimensional1ArchivoToolStripMenuItem_Click);
            // 
            // bidimensional2ArchivoToolStripMenuItem
            // 
            this.bidimensional2ArchivoToolStripMenuItem.Name = "bidimensional2ArchivoToolStripMenuItem";
            this.bidimensional2ArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.bidimensional2ArchivoToolStripMenuItem.Text = "Bidimensional 2 (Archivo)";
            this.bidimensional2ArchivoToolStripMenuItem.Click += new System.EventHandler(this.bidimensional2ArchivoToolStripMenuItem_Click);
            // 
            // bidimensional3ArchivoToolStripMenuItem
            // 
            this.bidimensional3ArchivoToolStripMenuItem.Name = "bidimensional3ArchivoToolStripMenuItem";
            this.bidimensional3ArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.bidimensional3ArchivoToolStripMenuItem.Text = "Bidimensional 3 (Archivo)";
            this.bidimensional3ArchivoToolStripMenuItem.Click += new System.EventHandler(this.bidimensional3ArchivoToolStripMenuItem_Click);
            // 
            // cerveceriaArchivoToolStripMenuItem
            // 
            this.cerveceriaArchivoToolStripMenuItem.Name = "cerveceriaArchivoToolStripMenuItem";
            this.cerveceriaArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.cerveceriaArchivoToolStripMenuItem.Text = "Cerveceria (Archivo)";
            this.cerveceriaArchivoToolStripMenuItem.Click += new System.EventHandler(this.cerveceriaArchivoToolStripMenuItem_Click);
            // 
            // datosAlumnosDocentesArchivoToolStripMenuItem
            // 
            this.datosAlumnosDocentesArchivoToolStripMenuItem.Name = "datosAlumnosDocentesArchivoToolStripMenuItem";
            this.datosAlumnosDocentesArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.datosAlumnosDocentesArchivoToolStripMenuItem.Text = "Datos Alumnos Docentes (Archivo)";
            this.datosAlumnosDocentesArchivoToolStripMenuItem.Click += new System.EventHandler(this.datosAlumnosDocentesArchivoToolStripMenuItem_Click);
            // 
            // miPrimerArraylistToolStripMenuItem1
            // 
            this.miPrimerArraylistToolStripMenuItem1.Name = "miPrimerArraylistToolStripMenuItem1";
            this.miPrimerArraylistToolStripMenuItem1.Size = new System.Drawing.Size(259, 22);
            this.miPrimerArraylistToolStripMenuItem1.Text = "Mi primer Arraylist";
            this.miPrimerArraylistToolStripMenuItem1.Click += new System.EventHandler(this.miPrimerArraylistToolStripMenuItem1_Click);
            // 
            // numerosMayorMenorArchivoToolStripMenuItem
            // 
            this.numerosMayorMenorArchivoToolStripMenuItem.Name = "numerosMayorMenorArchivoToolStripMenuItem";
            this.numerosMayorMenorArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.numerosMayorMenorArchivoToolStripMenuItem.Text = "Numeros Mayor Menor (Archivo)";
            this.numerosMayorMenorArchivoToolStripMenuItem.Click += new System.EventHandler(this.numerosMayorMenorArchivoToolStripMenuItem_Click);
            // 
            // paisesArchivoToolStripMenuItem
            // 
            this.paisesArchivoToolStripMenuItem.Name = "paisesArchivoToolStripMenuItem";
            this.paisesArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.paisesArchivoToolStripMenuItem.Text = "Paises (Archivo)";
            this.paisesArchivoToolStripMenuItem.Click += new System.EventHandler(this.paisesArchivoToolStripMenuItem_Click);
            // 
            // sumaMatrizArchivoToolStripMenuItem
            // 
            this.sumaMatrizArchivoToolStripMenuItem.Name = "sumaMatrizArchivoToolStripMenuItem";
            this.sumaMatrizArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.sumaMatrizArchivoToolStripMenuItem.Text = "Suma Matriz (Archivo)";
            this.sumaMatrizArchivoToolStripMenuItem.Click += new System.EventHandler(this.sumaMatrizArchivoToolStripMenuItem_Click);
            // 
            // torneoArchivoToolStripMenuItem
            // 
            this.torneoArchivoToolStripMenuItem.Name = "torneoArchivoToolStripMenuItem";
            this.torneoArchivoToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.torneoArchivoToolStripMenuItem.Text = "Torneo (Archivo)";
            this.torneoArchivoToolStripMenuItem.Click += new System.EventHandler(this.torneoArchivoToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(771, 389);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Catálogo de Gema Álvares";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem unidad2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unidad4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unidad6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unida6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miPrimerProyectoEnConsolaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miPrimerProyectoEnFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem areaPerimetroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asistenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calificacionesAlumnosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem casetaAutopistaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem electricidadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem embotelladoraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fechaNacimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gradosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vacacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empleadosRestauranteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figurasGeometricasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interfacesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehiculosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alcanciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alumnoDocenteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerveceriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem datosAlumnosDocentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejemplo1ArreglosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejemplo2ArreglosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejemplo3ArreglosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejemplo1PropuestoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miPrimerArraylistToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem numeroMayorMenorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paisesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sumaMatrizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alcanciaArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alumnoDocenteArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional1ArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional2ArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bidimensional3ArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerveceriaArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem datosAlumnosDocentesArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miPrimerArraylistToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem numerosMayorMenorArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paisesArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sumaMatrizArchivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem torneoArchivoToolStripMenuItem;
    }
}

