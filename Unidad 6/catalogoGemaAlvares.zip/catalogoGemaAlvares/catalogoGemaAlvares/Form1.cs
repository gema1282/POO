﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace catalogoGemaAlvares
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void arregloUnidimensionalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/alcancia/alcancia/bin/Debug/alcancia.exe";
            abrir.Start();
        }

        private void arreglosBiYUniDimensionalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/cerveceria/cerveceria/bin/Debug/cerveceria.exe";
            abrir.Start();
        }

        private void sumasDeMatrizFilasColumnasYDiagonalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/sumaMatriz/sumaMatriz/bin/Debug/sumaMatriz.exe";
            abrir.Start();
        }

        private void númerosMayorYMenorDeUnamatrizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/numeroMayoryMenor/numeroMayoryMenor/bin/Debug/numeroMayoryMenor.exe";
            abrir.Start();
        }

        private void miPrimerProyectoEnConsolaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 1/MiPrimerProyectoConsola/bin/Debug/MiPrimerProyectoConsola.exe";
            abrir.Start();
        }

        private void miPrimerProyectoEnFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 1/MiPrimerProyectoWindowsForms/bin/Debug/MiPrimerProyectoWindowsForms.exe";
            abrir.Start();
        }

        private void areaPerimetroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/AreaPerimetro/bin/Debug/AreaPerimetro.exe";
            abrir.Start();
        }

        private void asistenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/Asistente/bin/Debug/Asistente.exe";
            abrir.Start();
        }

        private void calificacionesAlumnosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/CalificacionesAlumnos/bin/Debug/CalificacionesAlumnos.exe";
            abrir.Start();
        }

        private void casetaAutopistaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/CasetaAutopista/bin/Debug/CasetaAutopista.exe";
            abrir.Start();
        }

        private void electricidadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/Electricidad/bin/Debug/Electricidad.exe";
            abrir.Start();
        }

        private void embotelladoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/Embotelladora/bin/Debug/Embotelladora.exe";
            abrir.Start();
        }

        private void fechaNacimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/FechaNacimiento/bin/Debug/FechaNacimiento.exe";
            abrir.Start();
        }

        private void gradosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/Grados/bin/Debug/Grados.exe";
            abrir.Start();
        }

        private void vacacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 2/Vacaciones/bin/Debug/Vacaciones.exe";
            abrir.Start();
        }

        private void empleadosRestauranteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 4/EmpleadosRestaurante/bin/Debug/EmpleadosRestaurante.exe";
            abrir.Start();
        }

        private void figurasGeometricasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 4/EmpleadosRestaurante/bin/Debug/EmpleadosRestaurante.exe";
            abrir.Start();
        }

        private void interfacesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 4/Interfaces/bin/Debug/Interfaces.exe";
            abrir.Start();
        }

        private void operacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 4/Operación/bin/Debug/Operación.exe";
            abrir.Start();
        }

        private void vehiculosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 4/Vehiculos/bin/Debug/Vehiculos.exe";
            abrir.Start();
        }

        private void alcanciaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Alcancia/bin/Debug/Alcancia.exe";
            abrir.Start();
        }

        private void alumnoDocenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/AlumnoDocente/bin/Debug/AlumnoDocente.exe";
            abrir.Start();
        }

        private void bidimensional1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/bidimencional1/bin/Debug/bidimencional1.exe";
            abrir.Start();
        }

        private void bidimensional2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Bidimensional2/bin/Debug/Bidimensional2.exe";
            abrir.Start();
        }

        private void bidimensional3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Bidimensional3/bin/Debug/Bidimensional3.exe";
            abrir.Start();
        }

        

        private void cerveceriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Cerveceria/bin/Debug/Cerveceria.exe";
            abrir.Start();
        }

        private void datosAlumnosDocentesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/DatosAlumnosDocentes/bin/Debug/DatosAlumnosDocentes.exe";
            abrir.Start();
        }

        private void ejemplo1ArreglosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Ejemplo1Arreglos/bin/Debug/Ejemplo1Arreglos.exe";
            abrir.Start();
        }

        private void ejemplo2ArreglosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Ejemplo2Arreglos/bin/Debug/Ejemplo2Arreglos.exe";
            abrir.Start();
        }

        private void ejemplo3ArreglosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Ejemplo3Arreglos/bin/Debug/Ejemplo3Arreglos.exe";
            abrir.Start();
        }

        private void ejemplo1PropuestoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Ejemplo1Propuesto/bin/Debug/Ejemplo1Propuesto.exe";
            abrir.Start();
        }

        private void miPrimerArraylistToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/MiPrimeyArrayList/bin/Debug/MiPrimeyArrayList.exe";
            abrir.Start();
        }

        private void numeroMayorMenorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/numeroMayorMenor/bin/Debug/numeroMayorMenor.exe";
            abrir.Start();
        }

        private void paisesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/Paises/bin/Debug/Paises.exe";
            abrir.Start();
        }

        private void sumaMatrizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 5/SumaMatriz/bin/Debug/SumaMatriz.exe";
            abrir.Start();
        }

        private void alcanciaArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/AlcanciaArchivo/bin/Debug/AlcanciaArchivo.exe";
            abrir.Start();
        }

        private void cerveceriaArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/cerveceriaArchivo/bin/Debug/cerveceriaArchivo.exe";
            abrir.Start();
        }

        private void alumnoDocenteArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/AlumnoDocenteArchivo/bin/Debug/AlumnoDocenteArchivo.exe";
            abrir.Start();
        }

        private void bidimensional1ArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/bidimensional1Archivo/bin/Debug/bidimensional1Archivo.exe";
            abrir.Start();
        }

        private void bidimensional2ArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/bidimensional2Archivo/bin/Debug/bidimensional2Archivo.exe";
            abrir.Start();
        }

        private void bidimensional3ArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/bidimensional3Archivo/bin/Debug/bidimensional3Archivo.exe";
            abrir.Start();
        }

        

        private void datosAlumnosDocentesArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/DatosAlumnosDocentes/bin/Debug/DatosAlumnosDocentes.exe";
            abrir.Start();
        }

        private void miPrimerArraylistToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/MiPrimerArrayList/bin/Debug/MiPrimerArrayList.exe";
            abrir.Start();
        }

        private void numerosMayorMenorArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/numeroMayorMenorArchivo/bin/Debug/numeroMayorMenorArchivo.exe";
            abrir.Start();
        }

        private void paisesArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/PaisesArchivo/bin/Debug/PaisesArchivo.exe";
            abrir.Start();
        }

        private void sumaMatrizArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/sumaMatrizArchivo/bin/Debug/sumaMatrizArchivo.exe";
            abrir.Start();
        }

        private void torneoArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process abrir = new Process();

            abrir.StartInfo.FileName = @"" + Directory.GetParent(
                                                Directory.GetParent(
                                                    Directory.GetParent(
                                                        Directory.GetParent(
                                                            Directory.GetCurrentDirectory()
                                                        ).ToString()
                                                    ).ToString()
                                                ).ToString()
                                             ).ToString() + "/Unidad 6/TorneoArchivo/bin/Debug/TorneoArchivo.exe";
            abrir.Start();
        }
    }
}
