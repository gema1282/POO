﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interfaces
{
    public partial class Form1 : Form
    {
        private DataTable dt;
        private int contador=0;
        private double total = 0, iva = 0, subtotal = 0;
        private Calculos calculo = new Calculos();
        public Form1()
        {
            InitializeComponent();
            dt = new DataTable();
            dt.Columns.Add("Codigo");
            dt.Columns.Add("Nombre");
            dt.Columns.Add("Descripcion");
            dt.Columns.Add("Cantidad");
            dt.Columns.Add("Precio/U");
            dt.Columns.Add("SubTotal");
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (txtCodigo.Text.Equals("") || txtDescripcion.Text.Equals("") || txtNombre.Text.Equals("") || numericUpDownCantidad.Text.Equals("0") || numericUpDownPrecio.Text.Equals("0.00"))
            {
                MessageBox.Show("Por favor rellena todos los campos y selecciona un precio y cantidad mayor a 0");
            }
            else {
                contador++;
                //operaciones usando la interfaz 
                subtotal = subtotal + calculo.calcularTotal(Convert.ToDouble(numericUpDownPrecio.Value), Convert.ToInt32(numericUpDownCantidad.Value));
                lblSubtotal.Text = subtotal.ToString();
                iva = calculo.calcularIVA(subtotal);
                lblIVA.Text = iva.ToString();
                total = calculo.totalVenta(iva, subtotal);
                lblTotal.Text = total.ToString();

                DataRow row = dt.NewRow();
                row["Codigo"] = txtCodigo.Text;
                row["Nombre"] = txtNombre.Text;
                row["Descripcion"] = txtDescripcion.Text;
                row["Cantidad"] = numericUpDownCantidad.Text;
                row["Precio/U"] = numericUpDownPrecio.Text;
                row["SubTotal"] = calculo.calcularTotal(Convert.ToDouble(numericUpDownPrecio.Value), Convert.ToInt32(numericUpDownCantidad.Value));
                dt.Rows.Add(row);

                txtCodigo.Text = "";
                txtNombre.Text = "";
                txtDescripcion.Text = "";
                numericUpDownCantidad.Text = "0";
                numericUpDownPrecio.Text = "0.00";
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.RowCount>=1)
            {
                btnEliminar.Enabled = true;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int numerodefila;
            if (dataGridView1.SelectedCells.Count > 0 && contador > 0)
            {
                numerodefila = dataGridView1.CurrentRow.Index;
                subtotal = subtotal - Convert.ToDouble(dataGridView1.CurrentRow.Cells[5].Value);
                lblSubtotal.Text = subtotal.ToString();
                iva = calculo.calcularIVA(subtotal);
                lblIVA.Text = iva.ToString();
                total = calculo.totalVenta(iva, subtotal);
                lblTotal.Text = total.ToString();
                dataGridView1.Rows.RemoveAt(numerodefila);
                contador--;
            }
            else if (contador == 0)
            {
                MessageBox.Show("Aún no existen registros");
            }
            else {
                MessageBox.Show("Por favor seleccione un producto");
            }
        }
    }
}
