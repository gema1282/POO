﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    interface cobros
    {
        double calcularIVA(double monto);
        double calcularTotal(double monto, int cantidad);

        double totalVenta(double iva, double monto);
    }
}
