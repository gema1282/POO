﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    class Calculos : cobros
    {
        public double calcularIVA(double monto)
        {
            double total;

            total = monto * 0.16;

            return total;
        }

        public double calcularTotal(double monto, int cantidad)
        {
            double total;

            total = monto * cantidad;

            return total;
        }

        public double totalVenta(double iva, double monto)
        {
            double total;

            total = iva + monto;
            return total;
        }
    }
}
