﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operación
{
    class Resta : Operacion
    {
        public void Restar()
        {
                Resultado = Valor1 - Valor2;
        }
    }
}
