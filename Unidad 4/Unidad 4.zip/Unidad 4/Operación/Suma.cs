﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operación
{
    class Suma: Operacion
    {
        /*Metodos de la clase*/
        public void Sumar()
        {
           Resultado = Valor1 + Valor2;
        }
    }
}
