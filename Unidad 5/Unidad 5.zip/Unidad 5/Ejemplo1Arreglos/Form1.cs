﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejemplo1Arreglos
{
    public partial class Form1 : Form
    {
        //Crear variable privada como atributo de la clase del form, la variable es de tipo List para guardar los objetos creados.
        private List<Pais> Paises = new List<Pais>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // validar que no haya campos vacios
            if (CamposVacios()) { MessageBox.Show("No puede dejar campos vacios"); return; }
            Pais pais = new Pais(); //Crea un objeto de clase pais
            //Asignarle sus atributos
            pais.Nombre = tbNombre.Text;
            pais.Poblacion = tbPoblacion.Text;
            pais.Idioma = tbIdioma.Text;
            pais.Colores[0] = tbColor1.Text;
            pais.Colores[1] = tbColor2.Text;
            pais.Colores[2] = tbColor3.Text;
            //Guardarlo en un ArrayList para posteriormente recuperarlo
            Paises.Add(pais);

            //Por ultimo limpiar los text box
            tbNombre.Text = "";
            tbPoblacion.Text = "";
            tbIdioma.Text = "";
            tbColor1.Text = "";
            tbColor2.Text = "";
            tbColor3.Text = "";
            MessageBox.Show("Datos guardados correctamente");
        }

        public bool CamposVacios()
        {
            if (tbNombre.Text == "") return true;
            else if (tbPoblacion.Text == "") return true;
            else if (tbIdioma.Text == "") return true;
            else if (tbColor1.Text == "" || tbColor2.Text == "" || tbColor3.Text == "") return true;
            else return false;
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            //Validar que el arraylist Pises tenga datos
            if (!(Paises.Count > 0)) { MessageBox.Show("No se tiene registrado ningun dato todavia"); return; }
            //Limpiar los registros del datagrid view
            dgvDatos.Rows.Clear();
            //Agregar los datos guardados en el arraylist Pais al datagridview
            DataGridViewRow fila = new DataGridViewRow();
            fila.CreateCells(dgvDatos);
            Pais pais = new Pais();
            for (int i = 0; i < Paises.Count; i++)
            {
                pais = Paises[i];
                fila.Cells[0].Value = pais.Nombre;
                fila.Cells[1].Value = pais.Poblacion;
                fila.Cells[2].Value = pais.Idioma;
                fila.Cells[3].Value = pais.Colores[0] + ", " + pais.Colores[1] + ", " + pais.Colores[2]; //Concatenar los 3 colores para ponerlos en una sola celda
                dgvDatos.Rows.Add(fila);
            }
        }
    }

    //Clase Pais
    class Pais
    {
        //Atributos de la clase pais
        public string Nombre;
        public string Poblacion;
        public string Idioma;
        public string[] Colores = new string[3]; //Arreglo para guardar los 3 colores

    }
}
