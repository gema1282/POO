﻿namespace Ejemplo1Arreglos
{
}