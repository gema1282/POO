﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paises
{
    class Paises
    {
        public string Nombre { set; get; }
        public int Poblacion { set; get; }
        public string Idioma { set; get; }
        public string[] ColBandera;
    }
}
