﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alcancia
{
    public partial class Form1 : Form
    {
        claseArreglo objArreglo = new claseArreglo();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            objArreglo.ahorrar(decimal.Parse(txtDinero.Text));
            lblArreglo.Text = objArreglo.imprimirArreglo();
            txtDinero.Text = "0.0";
        }

        private void btnRomper_Click(object sender, EventArgs e)
        {
            lblTextoTotal.Visible = true;
            lblTotal.Visible = true;
            lblTotal.Text = objArreglo.contarAhorros().ToString();
            lblArreglo.Text = lblArreglo.Text + "= " + lblTotal.Text;
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            lblTextoTotal.Visible = false;
            lblTotal.Visible = false;
            lblArreglo.Text = "[ ]";
            txtDinero.Text = "0.0";
        }
    }
}
