﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alcancia
{
    class claseArreglo
    {
        decimal[] ahorros = new decimal[0];
        int contador = 0;
        decimal total = 0;

        public void ahorrar(decimal cantidad)
        {
            Array.Resize(ref ahorros, ahorros.Length + 1);
            ahorros[contador] = cantidad;
            contador++;
        }

        public decimal contarAhorros()
        {
            for (int i = 0; i < ahorros.Length; i++)
            {
                total = total + ahorros[i];
            }
            return total;
        }

        public string imprimirArreglo()
        {
            string texto = "";
            for (int i = 0; i < ahorros.Length; i++)
            {
                texto = texto + "[ " + ahorros[i] + " ] ";
            }
            return texto;
        }
    }
}
