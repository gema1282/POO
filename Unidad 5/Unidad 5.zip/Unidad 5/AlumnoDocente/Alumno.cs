﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlumnoDocente
{
    class Alumno : Persona
    {
        public string NumeroControl { set; get; }
        public string Carrera { set; get; }
        public string[] Materia;
        public string[] Calificacion;
    }
}
