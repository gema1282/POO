﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace numeroMayorMenor
{
    public partial class Form1 : Form
    {
        claseMatriz objMatriz = new claseMatriz();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            objMatriz.crearMatriz(int.Parse(nUDTamano.Value.ToString()));

            lblMayor.Text = objMatriz.Mayor.ToString();
            lblMenor.Text = objMatriz.Menor.ToString();

            lblArreloUnidimensional.Text = objMatriz.imprimirArreglo();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lblArreloUnidimensional.Text = "[ ]";
            lblMayor.Text = "0";
            lblMenor.Text = "0";
            nUDTamano.Value = 2;
        }
    }
}
