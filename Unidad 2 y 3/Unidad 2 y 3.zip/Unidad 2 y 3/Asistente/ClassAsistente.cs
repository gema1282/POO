﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Asistente
{
    class ClassAsistente
    {
        public string asistente = "";
        public int cantidad = 0;
        public int bebes = 0;
        public int niños = 0;
        public int adultos = 0;
        public int adulMayores = 0;

        public void Contabilizar()
        {
            switch (asistente)
            {
                case "Bebes":
                    {
                        bebes = bebes + cantidad;
                        break;
                    }
                case "Niños":
                    {
                        niños = niños + cantidad;
                        break;
                    }
                case "Adultos":
                    {
                        adultos = adultos + cantidad;
                        break;
                    } 
                case "Adultos mayores":
                    {
                        adulMayores = adulMayores + cantidad;
                        break;
                    }
            }

        }
    }
}
