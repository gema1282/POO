﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Asistente
{
    public partial class Form1 : Form
    {
        ClassAsistente objAsistente = new ClassAsistente();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnContabilizar_Click(object sender, EventArgs e)
        {
            objAsistente.asistente = cmbAsistente.Text;
            objAsistente.cantidad = Convert.ToInt32(cmbCantidad.Text);
            objAsistente.Contabilizar();
            cmbAsistente.Text = ("");
            cmbCantidad.Text = ("");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            txtBebe.Text = objAsistente.bebes.ToString();
            txtNiño.Text = objAsistente.niños.ToString();
            txtAdultos.Text = objAsistente.adultos.ToString();
            txtAdulMayores.Text = objAsistente.adulMayores.ToString();
        }
    }
}
