﻿namespace Asistente
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblAdultosMayores = new System.Windows.Forms.Label();
            this.lblAdulto = new System.Windows.Forms.Label();
            this.lblNiño = new System.Windows.Forms.Label();
            this.lblBebe = new System.Windows.Forms.Label();
            this.btnContabilizar = new System.Windows.Forms.Button();
            this.cmbCantidad = new System.Windows.Forms.ComboBox();
            this.cmbAsistente = new System.Windows.Forms.ComboBox();
            this.lblAsistente = new System.Windows.Forms.Label();
            this.txtBebe = new System.Windows.Forms.TextBox();
            this.txtNiño = new System.Windows.Forms.TextBox();
            this.txtAdultos = new System.Windows.Forms.TextBox();
            this.txtAdulMayores = new System.Windows.Forms.TextBox();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(82, 222);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 26;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblAdultosMayores
            // 
            this.lblAdultosMayores.AutoSize = true;
            this.lblAdultosMayores.Location = new System.Drawing.Point(1, 185);
            this.lblAdultosMayores.Name = "lblAdultosMayores";
            this.lblAdultosMayores.Size = new System.Drawing.Size(69, 13);
            this.lblAdultosMayores.TabIndex = 25;
            this.lblAdultosMayores.Text = "Ad. Mayores:";
            // 
            // lblAdulto
            // 
            this.lblAdulto.AutoSize = true;
            this.lblAdulto.Location = new System.Drawing.Point(10, 158);
            this.lblAdulto.Name = "lblAdulto";
            this.lblAdulto.Size = new System.Drawing.Size(45, 13);
            this.lblAdulto.TabIndex = 24;
            this.lblAdulto.Text = "Adultos:";
            // 
            // lblNiño
            // 
            this.lblNiño.AutoSize = true;
            this.lblNiño.Location = new System.Drawing.Point(10, 131);
            this.lblNiño.Name = "lblNiño";
            this.lblNiño.Size = new System.Drawing.Size(37, 13);
            this.lblNiño.TabIndex = 23;
            this.lblNiño.Text = "Niños:";
            // 
            // lblBebe
            // 
            this.lblBebe.AutoSize = true;
            this.lblBebe.Location = new System.Drawing.Point(10, 104);
            this.lblBebe.Name = "lblBebe";
            this.lblBebe.Size = new System.Drawing.Size(40, 13);
            this.lblBebe.TabIndex = 22;
            this.lblBebe.Text = "Bebés:";
            // 
            // btnContabilizar
            // 
            this.btnContabilizar.Location = new System.Drawing.Point(46, 63);
            this.btnContabilizar.Name = "btnContabilizar";
            this.btnContabilizar.Size = new System.Drawing.Size(75, 23);
            this.btnContabilizar.TabIndex = 21;
            this.btnContabilizar.Text = "Contabilizar";
            this.btnContabilizar.UseVisualStyleBackColor = true;
            this.btnContabilizar.Click += new System.EventHandler(this.btnContabilizar_Click);
            // 
            // cmbCantidad
            // 
            this.cmbCantidad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCantidad.FormattingEnabled = true;
            this.cmbCantidad.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbCantidad.Location = new System.Drawing.Point(88, 36);
            this.cmbCantidad.Name = "cmbCantidad";
            this.cmbCantidad.Size = new System.Drawing.Size(69, 21);
            this.cmbCantidad.TabIndex = 20;
            // 
            // cmbAsistente
            // 
            this.cmbAsistente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAsistente.FormattingEnabled = true;
            this.cmbAsistente.Items.AddRange(new object[] {
            "Bebes",
            "Niños",
            "Adultos",
            "Adultos mayores"});
            this.cmbAsistente.Location = new System.Drawing.Point(66, 9);
            this.cmbAsistente.Name = "cmbAsistente";
            this.cmbAsistente.Size = new System.Drawing.Size(91, 21);
            this.cmbAsistente.TabIndex = 19;
            // 
            // lblAsistente
            // 
            this.lblAsistente.AutoSize = true;
            this.lblAsistente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAsistente.Location = new System.Drawing.Point(10, 12);
            this.lblAsistente.Name = "lblAsistente";
            this.lblAsistente.Size = new System.Drawing.Size(50, 13);
            this.lblAsistente.TabIndex = 18;
            this.lblAsistente.Text = "Asistente";
            // 
            // txtBebe
            // 
            this.txtBebe.Location = new System.Drawing.Point(57, 96);
            this.txtBebe.Name = "txtBebe";
            this.txtBebe.Size = new System.Drawing.Size(100, 20);
            this.txtBebe.TabIndex = 28;
            // 
            // txtNiño
            // 
            this.txtNiño.Location = new System.Drawing.Point(57, 123);
            this.txtNiño.Name = "txtNiño";
            this.txtNiño.Size = new System.Drawing.Size(100, 20);
            this.txtNiño.TabIndex = 29;
            // 
            // txtAdultos
            // 
            this.txtAdultos.Location = new System.Drawing.Point(57, 150);
            this.txtAdultos.Name = "txtAdultos";
            this.txtAdultos.Size = new System.Drawing.Size(100, 20);
            this.txtAdultos.TabIndex = 30;
            // 
            // txtAdulMayores
            // 
            this.txtAdulMayores.Location = new System.Drawing.Point(76, 182);
            this.txtAdulMayores.Name = "txtAdulMayores";
            this.txtAdulMayores.Size = new System.Drawing.Size(81, 20);
            this.txtAdulMayores.TabIndex = 31;
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Location = new System.Drawing.Point(13, 43);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(49, 13);
            this.lblCantidad.TabIndex = 32;
            this.lblCantidad.Text = "Cantidad";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(174, 261);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.txtAdulMayores);
            this.Controls.Add(this.txtAdultos);
            this.Controls.Add(this.txtNiño);
            this.Controls.Add(this.txtBebe);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblAdultosMayores);
            this.Controls.Add(this.lblAdulto);
            this.Controls.Add(this.lblNiño);
            this.Controls.Add(this.lblBebe);
            this.Controls.Add(this.btnContabilizar);
            this.Controls.Add(this.cmbCantidad);
            this.Controls.Add(this.cmbAsistente);
            this.Controls.Add(this.lblAsistente);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblAdultosMayores;
        private System.Windows.Forms.Label lblAdulto;
        private System.Windows.Forms.Label lblNiño;
        private System.Windows.Forms.Label lblBebe;
        private System.Windows.Forms.Button btnContabilizar;
        private System.Windows.Forms.ComboBox cmbCantidad;
        private System.Windows.Forms.ComboBox cmbAsistente;
        private System.Windows.Forms.Label lblAsistente;
        private System.Windows.Forms.TextBox txtBebe;
        private System.Windows.Forms.TextBox txtNiño;
        private System.Windows.Forms.TextBox txtAdultos;
        private System.Windows.Forms.TextBox txtAdulMayores;
        private System.Windows.Forms.Label lblCantidad;
    }
}

