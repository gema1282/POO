﻿namespace CasetaAutopista
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTipo = new System.Windows.Forms.ComboBox();
            this.lblVehiculo = new System.Windows.Forms.Label();
            this.btnCantidad = new System.Windows.Forms.Button();
            this.lblCantidadCobro = new System.Windows.Forms.Label();
            this.txtCantidadCobro = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cmbTipo
            // 
            this.cmbTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipo.FormattingEnabled = true;
            this.cmbTipo.Items.AddRange(new object[] {
            "Motociclista",
            "Automovil",
            "Autobus",
            "Trailer"});
            this.cmbTipo.Location = new System.Drawing.Point(99, 12);
            this.cmbTipo.Name = "cmbTipo";
            this.cmbTipo.Size = new System.Drawing.Size(121, 21);
            this.cmbTipo.TabIndex = 5;
            // 
            // lblVehiculo
            // 
            this.lblVehiculo.AutoSize = true;
            this.lblVehiculo.Location = new System.Drawing.Point(7, 15);
            this.lblVehiculo.Name = "lblVehiculo";
            this.lblVehiculo.Size = new System.Drawing.Size(86, 13);
            this.lblVehiculo.TabIndex = 4;
            this.lblVehiculo.Text = "Tipo de vehiculo";
            // 
            // btnCantidad
            // 
            this.btnCantidad.Location = new System.Drawing.Point(99, 39);
            this.btnCantidad.Name = "btnCantidad";
            this.btnCantidad.Size = new System.Drawing.Size(121, 23);
            this.btnCantidad.TabIndex = 3;
            this.btnCantidad.Text = "Cantidad de cobro";
            this.btnCantidad.UseVisualStyleBackColor = true;
            this.btnCantidad.Click += new System.EventHandler(this.btnCantidad_Click);
            // 
            // lblCantidadCobro
            // 
            this.lblCantidadCobro.AutoSize = true;
            this.lblCantidadCobro.Location = new System.Drawing.Point(17, 79);
            this.lblCantidadCobro.Name = "lblCantidadCobro";
            this.lblCantidadCobro.Size = new System.Drawing.Size(97, 13);
            this.lblCantidadCobro.TabIndex = 6;
            this.lblCantidadCobro.Text = "Cantidad de cobro:";
            // 
            // txtCantidadCobro
            // 
            this.txtCantidadCobro.Location = new System.Drawing.Point(120, 76);
            this.txtCantidadCobro.Name = "txtCantidadCobro";
            this.txtCantidadCobro.Size = new System.Drawing.Size(100, 20);
            this.txtCantidadCobro.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 116);
            this.Controls.Add(this.txtCantidadCobro);
            this.Controls.Add(this.lblCantidadCobro);
            this.Controls.Add(this.cmbTipo);
            this.Controls.Add(this.lblVehiculo);
            this.Controls.Add(this.btnCantidad);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTipo;
        private System.Windows.Forms.Label lblVehiculo;
        private System.Windows.Forms.Button btnCantidad;
        private System.Windows.Forms.Label lblCantidadCobro;
        private System.Windows.Forms.TextBox txtCantidadCobro;
    }
}

