﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CasetaAutopista
{
    class ClassVehiculo
    {
        public int cantidadCobro;
        public string vehiculo;

        public void CantidadCobro()
        {
            switch (vehiculo)
            {
                case "Motociclista":
                    {
                        cantidadCobro = 50;
                        break;
                    }
                case "Automovil":
                    {
                        cantidadCobro = 112;
                        break;
                    }
                case "Autobus":
                    {
                        cantidadCobro = 170;
                        break;
                    }
                default:
                    {
                        cantidadCobro = 250;
                        break;
                    }
            }
        }
    }
}
