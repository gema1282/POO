﻿namespace Grados
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRes = new System.Windows.Forms.Label();
            this.txtGrados = new System.Windows.Forms.TextBox();
            this.cmbUnidad = new System.Windows.Forms.ComboBox();
            this.btnConvertir = new System.Windows.Forms.Button();
            this.lblGradosCon = new System.Windows.Forms.Label();
            this.lblUnidad = new System.Windows.Forms.Label();
            this.lblGrados = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRes
            // 
            this.lblRes.AutoSize = true;
            this.lblRes.Location = new System.Drawing.Point(145, 187);
            this.lblRes.Name = "lblRes";
            this.lblRes.Size = new System.Drawing.Size(0, 13);
            this.lblRes.TabIndex = 13;
            // 
            // txtGrados
            // 
            this.txtGrados.Location = new System.Drawing.Point(54, 5);
            this.txtGrados.Name = "txtGrados";
            this.txtGrados.Size = new System.Drawing.Size(121, 20);
            this.txtGrados.TabIndex = 12;
            // 
            // cmbUnidad
            // 
            this.cmbUnidad.FormattingEnabled = true;
            this.cmbUnidad.Items.AddRange(new object[] {
            "Fharenheit",
            "Centigrados"});
            this.cmbUnidad.Location = new System.Drawing.Point(54, 31);
            this.cmbUnidad.Name = "cmbUnidad";
            this.cmbUnidad.Size = new System.Drawing.Size(121, 21);
            this.cmbUnidad.TabIndex = 11;
            // 
            // btnConvertir
            // 
            this.btnConvertir.Location = new System.Drawing.Point(100, 58);
            this.btnConvertir.Name = "btnConvertir";
            this.btnConvertir.Size = new System.Drawing.Size(75, 23);
            this.btnConvertir.TabIndex = 10;
            this.btnConvertir.Text = "Convertir";
            this.btnConvertir.UseVisualStyleBackColor = true;
            this.btnConvertir.Click += new System.EventHandler(this.btnConvertir_Click);
            // 
            // lblGradosCon
            // 
            this.lblGradosCon.AutoSize = true;
            this.lblGradosCon.Location = new System.Drawing.Point(7, 108);
            this.lblGradosCon.Name = "lblGradosCon";
            this.lblGradosCon.Size = new System.Drawing.Size(102, 13);
            this.lblGradosCon.TabIndex = 9;
            this.lblGradosCon.Text = "Grados convertidos:";
            // 
            // lblUnidad
            // 
            this.lblUnidad.AutoSize = true;
            this.lblUnidad.Location = new System.Drawing.Point(7, 39);
            this.lblUnidad.Name = "lblUnidad";
            this.lblUnidad.Size = new System.Drawing.Size(41, 13);
            this.lblUnidad.TabIndex = 8;
            this.lblUnidad.Text = "Unidad";
            // 
            // lblGrados
            // 
            this.lblGrados.AutoSize = true;
            this.lblGrados.Location = new System.Drawing.Point(7, 8);
            this.lblGrados.Name = "lblGrados";
            this.lblGrados.Size = new System.Drawing.Size(41, 13);
            this.lblGrados.TabIndex = 7;
            this.lblGrados.Text = "Grados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(186, 135);
            this.Controls.Add(this.lblRes);
            this.Controls.Add(this.txtGrados);
            this.Controls.Add(this.cmbUnidad);
            this.Controls.Add(this.btnConvertir);
            this.Controls.Add(this.lblGradosCon);
            this.Controls.Add(this.lblUnidad);
            this.Controls.Add(this.lblGrados);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRes;
        private System.Windows.Forms.TextBox txtGrados;
        private System.Windows.Forms.ComboBox cmbUnidad;
        private System.Windows.Forms.Button btnConvertir;
        private System.Windows.Forms.Label lblGradosCon;
        private System.Windows.Forms.Label lblUnidad;
        private System.Windows.Forms.Label lblGrados;
    }
}

