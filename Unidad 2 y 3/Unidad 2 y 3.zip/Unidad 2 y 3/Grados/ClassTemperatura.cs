﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grados
{
    class ClassTemperatura
    {
        public double grados;
        public string unidad;

        public void ConvertirGrados()
        {
            if (unidad == "Centigrados")
            {
                grados = (grados * 1.8000) + 32;
            }
            else
            {
                grados = (grados - 32) / 1.8000;
            }
        }
    }
}
