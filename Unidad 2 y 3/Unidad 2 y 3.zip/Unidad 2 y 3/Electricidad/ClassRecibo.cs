﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Electricidad
{
    class ClassRecibo
    {
        public double cantidadKW;
        public double consumo;
        public string tipo;

        public void Calcular()
        {
            switch (tipo)
            {
                case "Hogar":
                    {
                        if (cantidadKW > 0 & cantidadKW < 251)
                        {
                            consumo = cantidadKW * 0.65;
                        }
                        else if (cantidadKW > 250 & cantidadKW <= 500)
                        {
                            consumo = cantidadKW * 0.85;
                        }
                        else if (cantidadKW > 500 & cantidadKW <= 1200)
                        {
                            consumo = cantidadKW * 1.5;
                        }
                        else if (cantidadKW > 1200 & cantidadKW >= 2100)
                        {
                            consumo = cantidadKW * 2.5;
                        }
                        else
                        {
                            consumo = cantidadKW * 3;
                        }
                    }
                    break;
                case "Negocio":
                    {
                        consumo = cantidadKW * 5;
                        break;
                    }
            }
        }
    }
}
