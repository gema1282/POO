﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Electricidad
{
    public partial class Form1 : Form
    {
        ClassRecibo objRecibo = new ClassRecibo();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            objRecibo.tipo = cmbTipo.Text;
            objRecibo.cantidadKW = Convert.ToDouble(txtCantidad.Text);
            objRecibo.Calcular();
            MessageBox.Show(objRecibo.consumo.ToString());
        }
    }
}
