﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vacaciones
{
    class ClassEmpleado
    {
        public int dias = 0;
        public int años = 0;

        public int Dias()
        {
            if (años < 6)
            {
                dias = 5;
            }
            else if (años > 5 & años <= 10)
            {
                dias = 10;
            }
            else if (años > 10 & años <= 20)
            {
                dias = años;
            }
            else if (años > 20 & años < 33)
            {
                dias = (años + 10) + 2;
            }
            return dias;
        }
    }
}
