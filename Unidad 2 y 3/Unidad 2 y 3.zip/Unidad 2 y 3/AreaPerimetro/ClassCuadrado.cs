﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaPerimetro
{
    class ClassCuadrado
    {
        public int lado;
        public int area;
        public int perimetro;

        public void Calcular()
        {
            area = lado * lado;
            perimetro = lado * 4;
        }
    }
}
