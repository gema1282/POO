﻿namespace CalificacionesAlumnos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblPromedio = new System.Windows.Forms.Label();
            this.lblReprobados = new System.Windows.Forms.Label();
            this.lblAprobados = new System.Windows.Forms.Label();
            this.btnCapturar = new System.Windows.Forms.Button();
            this.txtCalificación = new System.Windows.Forms.TextBox();
            this.lblCalificación = new System.Windows.Forms.Label();
            this.txtAprobados = new System.Windows.Forms.TextBox();
            this.txtReprobados = new System.Windows.Forms.TextBox();
            this.txtPromedioGrupal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(63, 181);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 19;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblPromedio
            // 
            this.lblPromedio.AutoSize = true;
            this.lblPromedio.Location = new System.Drawing.Point(7, 149);
            this.lblPromedio.Name = "lblPromedio";
            this.lblPromedio.Size = new System.Drawing.Size(88, 13);
            this.lblPromedio.TabIndex = 18;
            this.lblPromedio.Text = "Promedio Grupal:";
            // 
            // lblReprobados
            // 
            this.lblReprobados.AutoSize = true;
            this.lblReprobados.Location = new System.Drawing.Point(7, 115);
            this.lblReprobados.Name = "lblReprobados";
            this.lblReprobados.Size = new System.Drawing.Size(68, 13);
            this.lblReprobados.TabIndex = 17;
            this.lblReprobados.Text = "Reprobados:";
            // 
            // lblAprobados
            // 
            this.lblAprobados.AutoSize = true;
            this.lblAprobados.Location = new System.Drawing.Point(7, 86);
            this.lblAprobados.Name = "lblAprobados";
            this.lblAprobados.Size = new System.Drawing.Size(61, 13);
            this.lblAprobados.TabIndex = 16;
            this.lblAprobados.Text = "Aprobados:";
            // 
            // btnCapturar
            // 
            this.btnCapturar.Location = new System.Drawing.Point(106, 50);
            this.btnCapturar.Name = "btnCapturar";
            this.btnCapturar.Size = new System.Drawing.Size(75, 23);
            this.btnCapturar.TabIndex = 15;
            this.btnCapturar.Text = "Capturar";
            this.btnCapturar.UseVisualStyleBackColor = true;
            this.btnCapturar.Click += new System.EventHandler(this.btnCapturar_Click);
            // 
            // txtCalificación
            // 
            this.txtCalificación.Location = new System.Drawing.Point(81, 15);
            this.txtCalificación.Name = "txtCalificación";
            this.txtCalificación.Size = new System.Drawing.Size(100, 20);
            this.txtCalificación.TabIndex = 14;
            // 
            // lblCalificación
            // 
            this.lblCalificación.AutoSize = true;
            this.lblCalificación.Location = new System.Drawing.Point(11, 18);
            this.lblCalificación.Name = "lblCalificación";
            this.lblCalificación.Size = new System.Drawing.Size(64, 13);
            this.lblCalificación.TabIndex = 13;
            this.lblCalificación.Text = "Calificación:";
            // 
            // txtAprobados
            // 
            this.txtAprobados.Location = new System.Drawing.Point(75, 83);
            this.txtAprobados.Name = "txtAprobados";
            this.txtAprobados.Size = new System.Drawing.Size(106, 20);
            this.txtAprobados.TabIndex = 20;
            // 
            // txtReprobados
            // 
            this.txtReprobados.Location = new System.Drawing.Point(75, 112);
            this.txtReprobados.Name = "txtReprobados";
            this.txtReprobados.Size = new System.Drawing.Size(106, 20);
            this.txtReprobados.TabIndex = 21;
            // 
            // txtPromedioGrupal
            // 
            this.txtPromedioGrupal.Location = new System.Drawing.Point(101, 146);
            this.txtPromedioGrupal.Name = "txtPromedioGrupal";
            this.txtPromedioGrupal.Size = new System.Drawing.Size(80, 20);
            this.txtPromedioGrupal.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(201, 216);
            this.Controls.Add(this.txtPromedioGrupal);
            this.Controls.Add(this.txtReprobados);
            this.Controls.Add(this.txtAprobados);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblPromedio);
            this.Controls.Add(this.lblReprobados);
            this.Controls.Add(this.lblAprobados);
            this.Controls.Add(this.btnCapturar);
            this.Controls.Add(this.txtCalificación);
            this.Controls.Add(this.lblCalificación);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblPromedio;
        private System.Windows.Forms.Label lblReprobados;
        private System.Windows.Forms.Label lblAprobados;
        private System.Windows.Forms.Button btnCapturar;
        private System.Windows.Forms.TextBox txtCalificación;
        private System.Windows.Forms.Label lblCalificación;
        private System.Windows.Forms.TextBox txtAprobados;
        private System.Windows.Forms.TextBox txtReprobados;
        private System.Windows.Forms.TextBox txtPromedioGrupal;
    }
}

