﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalificacionesAlumnos
{
    class ClassCalificaciones
    {
        public int calificacion = 0;
        public int aprobados = 0;
        public int reprobados = 0;
        int cont= 0;
        public double promedio = 0;
        int suma = 0;

        public void capturar()
        {
            if (calificacion >= 70)
            {
                aprobados = aprobados + 1;
                suma = suma + calificacion;
            }
            else
            {
                reprobados = reprobados + 1;
                suma = suma + calificacion;
            }
            cont++;
            promedio = suma / cont;
        }
    }
}
