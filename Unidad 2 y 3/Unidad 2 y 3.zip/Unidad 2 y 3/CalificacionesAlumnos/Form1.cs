﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalificacionesAlumnos
{
    public partial class Form1 : Form
    {
        ClassCalificaciones objCalificaciones = new ClassCalificaciones();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCapturar_Click(object sender, EventArgs e)
        {
            objCalificaciones.calificacion = int.Parse(txtCalificación.Text);
            objCalificaciones.capturar();
            txtCalificación.Text = "";
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            txtAprobados.Text = objCalificaciones.aprobados.ToString();
            txtReprobados.Text = objCalificaciones.reprobados.ToString();
            txtPromedioGrupal.Text = objCalificaciones.promedio.ToString();
        }
    }
}
