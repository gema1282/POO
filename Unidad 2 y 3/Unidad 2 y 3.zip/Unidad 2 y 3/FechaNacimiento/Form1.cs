﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FechaNacimiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            ClassPersona objPersona = new ClassPersona();

            objPersona.añoActual = int.Parse(DateTime.Today.Year.ToString());
            objPersona.añoNac = int.Parse(dtpFechaNac.Value.Year.ToString());
            objPersona.mesActual = int.Parse(DateTime.Today.Month.ToString());
            objPersona.mesNac = int.Parse(dtpFechaNac.Value.Month.ToString());
            objPersona.diaActual = int.Parse(DateTime.Today.Day.ToString());
            objPersona.diaNac = int.Parse(dtpFechaNac.Value.Day.ToString());
            MessageBox.Show(objPersona.MayorEdad());
        }
    }
}
