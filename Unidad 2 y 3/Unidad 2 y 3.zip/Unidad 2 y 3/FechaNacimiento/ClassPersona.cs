﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FechaNacimiento
{
    class ClassPersona
    {
        public int diaNac;
        public int diaActual;
        public int mesNac;
        public int mesActual;
        public int añoNac;
        public int añoActual;
        public string mayorEdad;

        public string MayorEdad()
        {
            if (añoActual - añoNac > 18)
            {
                mayorEdad = "Es Mayor de Edad";
            }
            else if (añoActual - añoNac == 18)
            {
                if (mesActual > mesNac)
                {
                    mayorEdad = "Es Mayor de Edad";
                }
                else if (mesActual == mesNac)
                {
                    if (diaActual >= diaNac)
                    {
                        mayorEdad = "Es Mayor de Edad";
                    }
                }
            }
            return mayorEdad;
        }
    }
}
